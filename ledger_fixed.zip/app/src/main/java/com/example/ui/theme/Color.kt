package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// 1. Google Pixel / Material You Theme
// ==========================================
val PixelDarkPrimary = Color(0xFFA8C7FA)
val PixelDarkOnPrimary = Color(0xFF003062)
val PixelDarkPrimaryContainer = Color(0xFF0842A0)
val PixelDarkOnPrimaryContainer = Color(0xFFD3E3FD)

val PixelDarkSecondary = Color(0xFF7FCFFF)
val PixelDarkOnSecondary = Color(0xFF00344F)
val PixelDarkSecondaryContainer = Color(0xFF004C70)
val PixelDarkOnSecondaryContainer = Color(0xFFC2E7FF)

val PixelDarkTertiary = Color(0xFF6DD58C)
val PixelDarkOnTertiary = Color(0xFF003919)
val PixelDarkTertiaryContainer = Color(0xFF0F5228)
val PixelDarkOnTertiaryContainer = Color(0xFFC4EED0)

val PixelDarkBackground = Color(0xFF111318)
val PixelDarkOnBackground = Color(0xFFE2E2E9)
val PixelDarkSurface = Color(0xFF1D2026)
val PixelDarkOnSurface = Color(0xFFE2E2E9)
val PixelDarkSurfaceVariant = Color(0xFF333842)
val PixelDarkOnSurfaceVariant = Color(0xFFC3C7D0)

val PixelLightPrimary = Color(0xFF1A73E8)
val PixelLightOnPrimary = Color(0xFFFFFFFF)
val PixelLightPrimaryContainer = Color(0xFFD3E3FD)
val PixelLightOnPrimaryContainer = Color(0xFF041E49)

val PixelLightSecondary = Color(0xFF00639B)
val PixelLightOnSecondary = Color(0xFFFFFFFF)
val PixelLightSecondaryContainer = Color(0xFFC2E7FF)
val PixelLightOnSecondaryContainer = Color(0xFF001D32)

val PixelLightTertiary = Color(0xFF1E8E3E)
val PixelLightOnTertiary = Color(0xFFFFFFFF)
val PixelLightTertiaryContainer = Color(0xFFCEEAD6)
val PixelLightOnTertiaryContainer = Color(0xFF0D652D)

val PixelLightBackground = Color(0xFFF8F9FA)
val PixelLightOnBackground = Color(0xFF1F1F1F)
val PixelLightSurface = Color(0xFFFFFFFF)
val PixelLightOnSurface = Color(0xFF1F1F1F)
val PixelLightSurfaceVariant = Color(0xFFF1F3F4)
val PixelLightOnSurfaceVariant = Color(0xFF5F6368)


// ==========================================
// 2. Apple iOS / Cupertino Theme
// ==========================================
val IosDarkPrimary = Color(0xFF0A84FF)
val IosDarkOnPrimary = Color(0xFFFFFFFF)
val IosDarkPrimaryContainer = Color(0xFF0040DD)
val IosDarkOnPrimaryContainer = Color(0xFFD0E2FF)

val IosDarkSecondary = Color(0xFF5E5CE6)
val IosDarkOnSecondary = Color(0xFFFFFFFF)
val IosDarkSecondaryContainer = Color(0xFF3634A3)
val IosDarkOnSecondaryContainer = Color(0xFFE5E4FF)

val IosDarkTertiary = Color(0xFF30D158)
val IosDarkOnTertiary = Color(0xFF003912)
val IosDarkTertiaryContainer = Color(0xFF195E2B)
val IosDarkOnTertiaryContainer = Color(0xFFD1FADF)

val IosDarkBackground = Color(0xFF000000)
val IosDarkOnBackground = Color(0xFFF2F2F7)
val IosDarkSurface = Color(0xFF1C1C1E)
val IosDarkOnSurface = Color(0xFFFFFFFF)
val IosDarkSurfaceVariant = Color(0xFF2C2C2E)
val IosDarkOnSurfaceVariant = Color(0xFF8E8E93)

val IosLightPrimary = Color(0xFF007AFF)
val IosLightOnPrimary = Color(0xFFFFFFFF)
val IosLightPrimaryContainer = Color(0xFFE5F1FF)
val IosLightOnPrimaryContainer = Color(0xFF002B66)

val IosLightSecondary = Color(0xFF5856D6)
val IosLightOnSecondary = Color(0xFFFFFFFF)
val IosLightSecondaryContainer = Color(0xFFEEEBFF)
val IosLightOnSecondaryContainer = Color(0xFF221F7A)

val IosLightTertiary = Color(0xFF34C759)
val IosLightOnTertiary = Color(0xFFFFFFFF)
val IosLightTertiaryContainer = Color(0xFFE4F9E9)
val IosLightOnTertiaryContainer = Color(0xFF0B5320)

val IosLightBackground = Color(0xFFF2F2F7)
val IosLightOnBackground = Color(0xFF000000)
val IosLightSurface = Color(0xFFFFFFFF)
val IosLightOnSurface = Color(0xFF000000)
val IosLightSurfaceVariant = Color(0xFFE5E5EA)
val IosLightOnSurfaceVariant = Color(0xFF8E8E93)


// ==========================================
// 3. Emerald Obsidian Theme (Default Ledger)
// ==========================================
val EmeraldDarkPrimary = Color(0xFF6EE7B7)
val EmeraldDarkOnPrimary = Color(0xFF022C22)
val EmeraldDarkPrimaryContainer = Color(0xFF065F46)
val EmeraldDarkOnPrimaryContainer = Color(0xFFA7F3D0)

val EmeraldDarkSecondary = Color(0xFFFCD34D)
val EmeraldDarkOnSecondary = Color(0xFF451A03)
val EmeraldDarkSecondaryContainer = Color(0xFF78350F)
val EmeraldDarkOnSecondaryContainer = Color(0xFFFEF3C7)

val EmeraldDarkTertiary = Color(0xFF67E8F9)
val EmeraldDarkOnTertiary = Color(0xFF083344)
val EmeraldDarkTertiaryContainer = Color(0xFF155E75)
val EmeraldDarkOnTertiaryContainer = Color(0xFFCFFAFE)

val EmeraldDarkBackground = Color(0xFF0B1311)
val EmeraldDarkOnBackground = Color(0xFFE6F4EA)
val EmeraldDarkSurface = Color(0xFF142420)
val EmeraldDarkOnSurface = Color(0xFFE6F4EA)
val EmeraldDarkSurfaceVariant = Color(0xFF203731)
val EmeraldDarkOnSurfaceVariant = Color(0xFF9CA3AF)

val EmeraldLightPrimary = Color(0xFF059669)
val EmeraldLightOnPrimary = Color(0xFFFFFFFF)
val EmeraldLightPrimaryContainer = Color(0xFFD1FAE5)
val EmeraldLightOnPrimaryContainer = Color(0xFF064E3B)

val EmeraldLightSecondary = Color(0xFFD97706)
val EmeraldLightOnSecondary = Color(0xFFFFFFFF)
val EmeraldLightSecondaryContainer = Color(0xFFFEF3C7)
val EmeraldLightOnSecondaryContainer = Color(0xFF78350F)

val EmeraldLightTertiary = Color(0xFF0891B2)
val EmeraldLightOnTertiary = Color(0xFFFFFFFF)
val EmeraldLightTertiaryContainer = Color(0xFFCFFAFE)
val EmeraldLightOnTertiaryContainer = Color(0xFF164E63)

val EmeraldLightBackground = Color(0xFFF6FAF7)
val EmeraldLightOnBackground = Color(0xFF0F172A)
val EmeraldLightSurface = Color(0xFFFFFFFF)
val EmeraldLightOnSurface = Color(0xFF0F172A)
val EmeraldLightSurfaceVariant = Color(0xFFE2E8F0)
val EmeraldLightOnSurfaceVariant = Color(0xFF64748B)


// ==========================================
// 4. Midnight OLED Dark Theme (Pitch Black)
// ==========================================
val OledDarkPrimary = Color(0xFF22D3EE)
val OledDarkOnPrimary = Color(0xFF003640)
val OledDarkPrimaryContainer = Color(0xFF004F5D)
val OledDarkOnPrimaryContainer = Color(0xFF67E8F9)

val OledDarkSecondary = Color(0xFFF472B6)
val OledDarkOnSecondary = Color(0xFF500724)
val OledDarkSecondaryContainer = Color(0xFF831843)
val OledDarkOnSecondaryContainer = Color(0xFFFBCFE8)

val OledDarkTertiary = Color(0xFFC084FC)
val OledDarkOnTertiary = Color(0xFF3B0764)
val OledDarkTertiaryContainer = Color(0xFF581C87)
val OledDarkOnTertiaryContainer = Color(0xFFE9D5FF)

val OledDarkBackground = Color(0xFF000000)
val OledDarkOnBackground = Color(0xFFFFFFFF)
val OledDarkSurface = Color(0xFF0A0A0C)
val OledDarkOnSurface = Color(0xFFF4F4F5)
val OledDarkSurfaceVariant = Color(0xFF18181B)
val OledDarkOnSurfaceVariant = Color(0xFFA1A1AA)

val OledLightPrimary = Color(0xFF0891B2)
val OledLightOnPrimary = Color(0xFFFFFFFF)
val OledLightPrimaryContainer = Color(0xFFCCFBF1)
val OledLightOnPrimaryContainer = Color(0xFF115E59)

val OledLightSecondary = Color(0xFFDB2777)
val OledLightOnSecondary = Color(0xFFFFFFFF)
val OledLightSecondaryContainer = Color(0xFFFCE7F3)
val OledLightOnSecondaryContainer = Color(0xFF831843)

val OledLightTertiary = Color(0xFF9333EA)
val OledLightOnTertiary = Color(0xFFFFFFFF)
val OledLightTertiaryContainer = Color(0xFFF3E8FF)
val OledLightOnTertiaryContainer = Color(0xFF581C87)

val OledLightBackground = Color(0xFFFFFFFF)
val OledLightOnBackground = Color(0xFF09090B)
val OledLightSurface = Color(0xFFFAFAFA)
val OledLightOnSurface = Color(0xFF09090B)
val OledLightSurfaceVariant = Color(0xFFF4F4F5)
val OledLightOnSurfaceVariant = Color(0xFF71717A)


// ==========================================
// 5. Sunset Gold & Amber Theme
// ==========================================
val SunsetDarkPrimary = Color(0xFFFCD34D)
val SunsetDarkOnPrimary = Color(0xFF451A03)
val SunsetDarkPrimaryContainer = Color(0xFF78350F)
val SunsetDarkOnPrimaryContainer = Color(0xFFFEF3C7)

val SunsetDarkSecondary = Color(0xFFFB923C)
val SunsetDarkOnSecondary = Color(0xFF431407)
val SunsetDarkSecondaryContainer = Color(0xFF7C2D12)
val SunsetDarkOnSecondaryContainer = Color(0xFFFFEDD5)

val SunsetDarkTertiary = Color(0xFFF87171)
val SunsetDarkOnTertiary = Color(0xFF450A0A)
val SunsetDarkTertiaryContainer = Color(0xFF7F1D1D)
val SunsetDarkOnTertiaryContainer = Color(0xFFFEE2E2)

val SunsetDarkBackground = Color(0xFF171314)
val SunsetDarkOnBackground = Color(0xFFFDF6ED)
val SunsetDarkSurface = Color(0xFF261F21)
val SunsetDarkOnSurface = Color(0xFFFDF6ED)
val SunsetDarkSurfaceVariant = Color(0xFF382F32)
val SunsetDarkOnSurfaceVariant = Color(0xFFD6C4BD)

val SunsetLightPrimary = Color(0xFFD97706)
val SunsetLightOnPrimary = Color(0xFFFFFFFF)
val SunsetLightPrimaryContainer = Color(0xFFFEF3C7)
val SunsetLightOnPrimaryContainer = Color(0xFF451A03)

val SunsetLightSecondary = Color(0xFFEA580C)
val SunsetLightOnSecondary = Color(0xFFFFFFFF)
val SunsetLightSecondaryContainer = Color(0xFFFFEDD5)
val SunsetLightOnSecondaryContainer = Color(0xFF431407)

val SunsetLightTertiary = Color(0xFFDC2626)
val SunsetLightOnTertiary = Color(0xFFFFFFFF)
val SunsetLightTertiaryContainer = Color(0xFFFEE2E2)
val SunsetLightOnTertiaryContainer = Color(0xFF450A0A)

val SunsetLightBackground = Color(0xFFFAF7F5)
val SunsetLightOnBackground = Color(0xFF231B19)
val SunsetLightSurface = Color(0xFFFFFFFF)
val SunsetLightOnSurface = Color(0xFF231B19)
val SunsetLightSurfaceVariant = Color(0xFFF0EBE7)
val SunsetLightOnSurfaceVariant = Color(0xFF7C6E68)


// ==========================================
// 6. Nordic Glacier & Arctic Theme
// ==========================================
val NordicDarkPrimary = Color(0xFF7DD3FC)
val NordicDarkOnPrimary = Color(0xFF03354B)
val NordicDarkPrimaryContainer = Color(0xFF075985)
val NordicDarkOnPrimaryContainer = Color(0xFFE0F2FE)

val NordicDarkSecondary = Color(0xFF5EEAD4)
val NordicDarkOnSecondary = Color(0xFF003831)
val NordicDarkSecondaryContainer = Color(0xFF0F766E)
val NordicDarkOnSecondaryContainer = Color(0xFFCCFBF1)

val NordicDarkTertiary = Color(0xFFA5B4FC)
val NordicDarkOnTertiary = Color(0xFF1E1B4B)
val NordicDarkTertiaryContainer = Color(0xFF3730A3)
val NordicDarkOnTertiaryContainer = Color(0xFFE0E7FF)

val NordicDarkBackground = Color(0xFF0C141D)
val NordicDarkOnBackground = Color(0xFFF0F9FF)
val NordicDarkSurface = Color(0xFF152230)
val NordicDarkOnSurface = Color(0xFFF0F9FF)
val NordicDarkSurfaceVariant = Color(0xFF24364A)
val NordicDarkOnSurfaceVariant = Color(0xFF94A3B8)

val NordicLightPrimary = Color(0xFF0284C7)
val NordicLightOnPrimary = Color(0xFFFFFFFF)
val NordicLightPrimaryContainer = Color(0xFFE0F2FE)
val NordicLightOnPrimaryContainer = Color(0xFF082F49)

val NordicLightSecondary = Color(0xFF0D9488)
val NordicLightOnSecondary = Color(0xFFFFFFFF)
val NordicLightSecondaryContainer = Color(0xFFCCFBF1)
val NordicLightOnSecondaryContainer = Color(0xFF134E4A)

val NordicLightTertiary = Color(0xFF4F46E5)
val NordicLightOnTertiary = Color(0xFFFFFFFF)
val NordicLightTertiaryContainer = Color(0xFFE0E7FF)
val NordicLightOnTertiaryContainer = Color(0xFF1E1B4B)

val NordicLightBackground = Color(0xFFF8FAFC)
val NordicLightOnBackground = Color(0xFF0F172A)
val NordicLightSurface = Color(0xFFFFFFFF)
val NordicLightOnSurface = Color(0xFF0F172A)
val NordicLightSurfaceVariant = Color(0xFFF1F5F9)
val NordicLightOnSurfaceVariant = Color(0xFF64748B)


// ==========================================
// Semantic & Category Colors
// ==========================================
val BillsColor = Color(0xFF818CF8)
val BillsContainerColor = Color(0xFF312E81)

val LifestyleColor = Color(0xFFF472B6)
val LifestyleContainerColor = Color(0xFF831843)

val DebtSavingsColor = Color(0xFF34D399)
val DebtSavingsContainerColor = Color(0xFF064E3B)

val IncomeGreen = Color(0xFF4ADE80)
val ExpenseRed = Color(0xFFF87171)
val WarningAmber = Color(0xFFFBBF24)
val CardBorderDark = Color(0xFF334155)


