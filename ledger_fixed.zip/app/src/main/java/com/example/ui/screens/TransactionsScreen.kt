package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryGroup
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.MonthPickerHeader
import com.example.ui.components.TransactionItemCard
import com.example.ui.theme.BillsColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LifestyleColor
import com.example.ui.viewmodel.FilterState
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransactionsScreen(
    selectedMonth: String,
    transactions: List<TransactionEntity>,
    allMonthTransactions: List<TransactionEntity>,
    filterState: FilterState,
    currencySymbol: String,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onUpdateFilter: ((FilterState) -> FilterState) -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onTogglePaid: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onAddTransaction: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Extract unique tags in this month
    val availableTags = remember(allMonthTransactions) {
        allMonthTransactions.flatMap { it.tags.split(",") }
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    val filteredSum = remember(transactions) {
        val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        Pair(income, expense)
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Month Picker Header
            item {
                MonthPickerHeader(
                    selectedMonth = selectedMonth,
                    onPreviousMonth = onPreviousMonth,
                    onNextMonth = onNextMonth
                )
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = filterState.searchQuery,
                    onValueChange = { q -> onUpdateFilter { it.copy(searchQuery = q) } },
                    placeholder = { Text("Search title, category, tags, or notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (filterState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onUpdateFilter { it.copy(searchQuery = "") } }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("search_transactions_input")
                )
            }

            // Category Group Tab Filters
            item {
                val tabs = listOf(
                    Pair("All", null),
                    Pair("1. Bills (53%)", CategoryGroup.BILLS),
                    Pair("2. Lifestyle (24%)", CategoryGroup.LIFESTYLE),
                    Pair("3. Debt & Savings (23%)", CategoryGroup.DEBT_AND_SAVINGS),
                    Pair("Base Income", CategoryGroup.INCOME_BASE),
                    Pair("Extra Income", CategoryGroup.INCOME_EXTRA)
                )

                val selectedIndex = tabs.indexOfFirst { it.second == filterState.categoryGroup }.coerceAtLeast(0)

                ScrollableTabRow(
                    selectedTabIndex = selectedIndex,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    tabs.forEachIndexed { index, (label, group) ->
                        Tab(
                            selected = filterState.categoryGroup == group,
                            onClick = {
                                onUpdateFilter { it.copy(categoryGroup = group) }
                            },
                            text = {
                                Text(
                                    text = label,
                                    fontWeight = if (filterState.categoryGroup == group) FontWeight.Bold else FontWeight.Normal,
                                    color = when (group) {
                                        CategoryGroup.BILLS -> BillsColor
                                        CategoryGroup.LIFESTYLE -> LifestyleColor
                                        CategoryGroup.DEBT_AND_SAVINGS -> DebtSavingsColor
                                        CategoryGroup.INCOME_BASE, CategoryGroup.INCOME_EXTRA -> IncomeGreen
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        )
                    }
                }
            }

            // Secondary Filters (Tags & Unpaid toggle)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Unpaid toggle chip
                    FilterChip(
                        selected = filterState.showUnpaidOnly,
                        onClick = { onUpdateFilter { it.copy(showUnpaidOnly = !it.showUnpaidOnly) } },
                        label = { Text("Unpaid Only", style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ExpenseRed.copy(alpha = 0.2f),
                            selectedLabelColor = ExpenseRed
                        )
                    )

                    // Tags chips
                    availableTags.forEach { tag ->
                        FilterChip(
                            selected = filterState.selectedTag == tag,
                            onClick = {
                                onUpdateFilter {
                                    it.copy(selectedTag = if (it.selectedTag == tag) "" else tag)
                                }
                            },
                            label = { Text("#$tag", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Filter status summary bar
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Showing ${transactions.size} records",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (filteredSum.first > 0) {
                                Text(
                                    text = "In: +${CurrencyFormatter.formatCompact(filteredSum.first, currencySymbol)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = IncomeGreen
                                )
                            }
                            if (filteredSum.second > 0) {
                                Text(
                                    text = "Ex: -${CurrencyFormatter.formatCompact(filteredSum.second, currencySymbol)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = ExpenseRed
                                )
                            }
                        }
                    }
                }
            }

            // Transaction items
            if (transactions.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No matching items found.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    TransactionItemCard(
                        transaction = tx,
                        currencySymbol = currencySymbol,
                        onTogglePaid = { onTogglePaid(tx) },
                        onClick = { onTransactionClick(tx) },
                        onDelete = { onDeleteTransaction(tx) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(88.dp))
            }
        }

        // Floating Action Button to Add Item
        FloatingActionButton(
            onClick = onAddTransaction,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 20.dp)
                .testTag("fab_add_transaction"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Transaction")
        }
    }
}
