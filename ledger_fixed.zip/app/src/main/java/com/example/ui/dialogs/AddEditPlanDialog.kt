package com.example.ui.dialogs

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryGroup
import com.example.data.model.FuturePlanEntity
import com.example.data.model.PlanType
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.LifestyleColor
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import kotlin.math.ceil

@Composable
fun AddEditPlanDialog(
    initialPlan: FuturePlanEntity? = null,
    currentMonthKey: String = DateUtils.currentMonthKey(),
    currencySymbol: String = "৳",
    onDismiss: () -> Unit,
    onSave: (FuturePlanEntity) -> Unit,
    onDelete: ((FuturePlanEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(initialPlan?.title ?: "") }
    var planType by remember { mutableStateOf(initialPlan?.planType ?: PlanType.DEBT_REPAYMENT) }
    var totalTargetInput by remember {
        mutableStateOf(if (initialPlan != null) (if (initialPlan.totalTargetAmount % 1.0 == 0.0) initialPlan.totalTargetAmount.toLong().toString() else initialPlan.totalTargetAmount.toString()) else "30000")
    }
    var monthlyInstallmentInput by remember {
        mutableStateOf(if (initialPlan != null) (if (initialPlan.monthlyInstallmentAmount % 1.0 == 0.0) initialPlan.monthlyInstallmentAmount.toLong().toString() else initialPlan.monthlyInstallmentAmount.toString()) else "5000")
    }
    var paidAmountInput by remember {
        mutableStateOf(if (initialPlan != null) (if (initialPlan.paidAmount % 1.0 == 0.0) initialPlan.paidAmount.toLong().toString() else initialPlan.paidAmount.toString()) else "0")
    }
    var startMonthKey by remember { mutableStateOf(initialPlan?.startMonthKey ?: currentMonthKey) }
    var categoryName by remember { mutableStateOf(initialPlan?.categoryName ?: "Debt 1") }
    var paymentAccount by remember { mutableStateOf(initialPlan?.paymentAccount ?: "MTB Bank") }
    var notes by remember { mutableStateOf(initialPlan?.notes ?: "") }

    val totalTarget = totalTargetInput.toDoubleOrNull() ?: 0.0
    val monthlyInstallment = monthlyInstallmentInput.toDoubleOrNull() ?: 0.0
    val paidAmount = paidAmountInput.toDoubleOrNull() ?: 0.0

    val calculatedDurationMonths = remember(totalTarget, monthlyInstallment) {
        if (monthlyInstallment > 0 && totalTarget > 0) {
            ceil(totalTarget / monthlyInstallment).toInt().coerceAtLeast(1)
        } else {
            initialPlan?.durationMonths ?: 6
        }
    }

    val quickTitles = when (planType) {
        PlanType.DEBT_REPAYMENT -> listOf("MTB Bank Repayment", "Meghna Bank Loan", "Debt 1", "Debt 2", "Credit Card Clearance")
        PlanType.INVESTMENT_DPS -> listOf("DPS Scheme 1", "DPS Scheme 2", "Fixed Deposit Accumulation", "Pension Scheme")
        PlanType.SAVINGS_GOAL -> listOf("Emergency Fund Target", "Yearly Savings Buffer", "Investment Fund", "Wedding/Event Goal")
        PlanType.FUTURE_EXPENSE -> listOf("Khulna Family Fund", "Travel & Vacation Plan", "Home Renovation", "Gadget Upgrade")
    }

    val accounts = listOf("MTB Bank", "Meghna Bank", "bKash", "Cash", "Bank Transfer", "Credit Card")

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.96f),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (planType == PlanType.DEBT_REPAYMENT) Icons.Default.AccountBalance else Icons.Default.Savings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (initialPlan == null) "New Multi-Month Plan" else "Edit Plan Roadmap",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Plan Type Chips
                Text(
                    text = "PLAN TYPE",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp, fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlanType.entries.forEach { type ->
                        FilterChip(
                            selected = planType == type,
                            onClick = {
                                planType = type
                                when (type) {
                                    PlanType.DEBT_REPAYMENT -> categoryName = "Debt 1"
                                    PlanType.INVESTMENT_DPS -> categoryName = "DPS"
                                    PlanType.SAVINGS_GOAL -> categoryName = "Savings"
                                    PlanType.FUTURE_EXPENSE -> categoryName = "Khulna"
                                }
                            },
                            label = { Text(type.displayName, fontSize = 12.sp) }
                        )
                    }
                }

                // Title Input + Quick Suggestions
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Plan / Commitment Title") },
                    placeholder = { Text("e.g. MTB Bank Loan Repayment") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plan_title_input")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickTitles.forEach { suggestion ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            onClick = { title = suggestion }
                        ) {
                            Text(
                                text = suggestion,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Total Amount & Monthly Installment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = totalTargetInput,
                        onValueChange = { totalTargetInput = it },
                        label = { Text("Total Target ($currencySymbol)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("plan_total_input")
                    )

                    OutlinedTextField(
                        value = monthlyInstallmentInput,
                        onValueChange = { monthlyInstallmentInput = it },
                        label = { Text("Monthly ($currencySymbol/mo)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("plan_monthly_input")
                    )
                }

                // Paid so far & Start Month
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = paidAmountInput,
                        onValueChange = { paidAmountInput = it },
                        label = { Text("Already Paid ($currencySymbol)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = startMonthKey,
                        onValueChange = { startMonthKey = it },
                        label = { Text("Start Month (YYYY-MM)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Calculation Summary Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Estimated Timeline:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$calculatedDurationMonths Months",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        val remaining = (totalTarget - paidAmount).coerceAtLeast(0.0)
                        val monthsLeft = if (monthlyInstallment > 0) ceil(remaining / monthlyInstallment).toInt() else 0
                        Text(
                            text = "Remaining: ${CurrencyFormatter.format(remaining, currencySymbol)} • Approx $monthsLeft installments remaining",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Payment Account
                Text(
                    text = "PAYMENT METHOD / ACCOUNT",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp, fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    accounts.forEach { acc ->
                        FilterChip(
                            selected = paymentAccount == acc,
                            onClick = { paymentAccount = acc },
                            label = { Text(acc, fontSize = 12.sp) }
                        )
                    }
                }

                // Notes / Strategy
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes & Schedule Rules (Optional)") },
                    placeholder = { Text("e.g. Pay before 10th of every month") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && totalTarget > 0 && monthlyInstallment > 0) {
                        val categoryGroup = when (planType) {
                            PlanType.DEBT_REPAYMENT, PlanType.INVESTMENT_DPS, PlanType.SAVINGS_GOAL -> CategoryGroup.DEBT_AND_SAVINGS
                            PlanType.FUTURE_EXPENSE -> CategoryGroup.LIFESTYLE
                        }
                        val isDone = paidAmount >= totalTarget
                        onSave(
                            FuturePlanEntity(
                                id = initialPlan?.id ?: 0,
                                title = title.trim(),
                                planType = planType,
                                totalTargetAmount = totalTarget,
                                monthlyInstallmentAmount = monthlyInstallment,
                                startMonthKey = startMonthKey.trim(),
                                durationMonths = calculatedDurationMonths,
                                paidAmount = paidAmount,
                                categoryGroup = categoryGroup,
                                categoryName = categoryName.ifBlank { "Debt" },
                                paymentAccount = paymentAccount,
                                notes = notes.trim(),
                                isCompleted = isDone
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("save_plan_btn")
            ) {
                Text(if (initialPlan == null) "Create Roadmap" else "Save Changes")
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (initialPlan != null && onDelete != null) {
                    IconButton(onClick = { onDelete(initialPlan) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
                OutlinedButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            }
        }
    )
}
