package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryComparisonDelta
import com.example.data.model.CategoryGroup
import com.example.data.model.ComparisonPreset
import com.example.data.model.PeriodStats
import com.example.data.model.TimeFrameCalculator
import com.example.data.model.TimeFrameComparisonResult
import com.example.data.model.TransactionEntity
import com.example.ui.theme.BillsColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LifestyleColor
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils

@Composable
fun TimeFrameComparisonView(
    allTransactions: List<TransactionEntity>,
    currentMonthKey: String,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    var selectedPreset by remember { mutableStateOf(ComparisonPreset.MONTH_OVER_MONTH) }
    var customMonth1 by remember { mutableStateOf(currentMonthKey) }
    var customMonth2 by remember { mutableStateOf(DateUtils.getPreviousMonth(currentMonthKey)) }

    val comparisonResult = remember(selectedPreset, customMonth1, customMonth2, allTransactions, currentMonthKey) {
        val (p1Def, p2Def) = if (selectedPreset == ComparisonPreset.CUSTOM) {
            Pair(
                Pair(DateUtils.formatDisplayMonth(customMonth1), listOf(customMonth1)),
                Pair(DateUtils.formatDisplayMonth(customMonth2), listOf(customMonth2))
            )
        } else {
            TimeFrameCalculator.generatePresetPeriods(selectedPreset, currentMonthKey)
        }

        val p1Stats = TimeFrameCalculator.computePeriodStats(p1Def.first, p1Def.second, allTransactions)
        val p2Stats = TimeFrameCalculator.computePeriodStats(p2Def.first, p2Def.second, allTransactions)

        TimeFrameCalculator.comparePeriods(selectedPreset, p1Stats, p2Stats, allTransactions)
    }

    // Available distinct months for custom picker
    val distinctMonths = remember(allTransactions) {
        val list = allTransactions.map { it.monthYearKey }.distinct().toMutableList()
        if (!list.contains(currentMonthKey)) list.add(currentMonthKey)
        val prev = DateUtils.getPreviousMonth(currentMonthKey)
        if (!list.contains(prev)) list.add(prev)
        list.sortedDescending()
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Preset Selection Header Chips
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CompareArrows,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Timeframe Range Presets",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Scrollable chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ComparisonPreset.values().forEach { preset ->
                        val isSelected = selectedPreset == preset
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedPreset = preset },
                            label = {
                                Text(
                                    preset.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                // Preset subtitle
                Text(
                    text = selectedPreset.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Custom Selectors if Custom is selected
                if (selectedPreset == ComparisonPreset.CUSTOM) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Month 1 Picker
                        MonthDropdownSelector(
                            label = "Period 1 (Focus)",
                            selectedMonth = customMonth1,
                            options = distinctMonths,
                            onSelect = { customMonth1 = it },
                            modifier = Modifier.weight(1f)
                        )

                        Text("vs", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                        // Month 2 Picker
                        MonthDropdownSelector(
                            label = "Period 2 (Baseline)",
                            selectedMonth = customMonth2,
                            options = distinctMonths,
                            onSelect = { customMonth2 = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Active Comparison Legend Banner
        ComparisonLegendCard(
            period1Label = comparisonResult.period1.label,
            period2Label = comparisonResult.period2.label
        )

        // KPI Delta Badges
        ComparisonKpiGrid(
            result = comparisonResult,
            currencySymbol = currencySymbol
        )

        // Visual Representation 1: Side-by-Side Comparative Dual-Bar Chart
        SideBySideComparisonChart(
            result = comparisonResult,
            currencySymbol = currencySymbol
        )

        // Visual Representation 2: 53/24/23 Category Group Allocation Shift
        CategoryAllocationComparisonCard(
            period1 = comparisonResult.period1,
            period2 = comparisonResult.period2,
            currencySymbol = currencySymbol
        )

        // Visual Representation 3: Trajectory Breakdown (if multi-month)
        if (comparisonResult.period1.monthlyBreakdown.size > 1 || comparisonResult.period2.monthlyBreakdown.size > 1) {
            MultiMonthTrajectoryCard(
                period1 = comparisonResult.period1,
                period2 = comparisonResult.period2,
                currencySymbol = currencySymbol
            )
        }

        // Visual Representation 4: Top Category Shifts
        if (comparisonResult.categoryDeltas.isNotEmpty()) {
            CategoryVarianceRankCard(
                deltas = comparisonResult.categoryDeltas,
                currencySymbol = currencySymbol
            )
        }
    }
}

@Composable
private fun ComparisonLegendCard(
    period1Label: String,
    period2Label: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Column {
                    Text(
                        text = "Period 1 (Recent)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = period1Label,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Text(
                text = "VS",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.outline
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Spacer(modifier = Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Period 2 (Prior)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = period2Label,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary)
                )
            }
        }
    }
}

@Composable
private fun ComparisonKpiGrid(
    result: TimeFrameComparisonResult,
    currencySymbol: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Income KPI
            KpiDeltaCard(
                title = "Total Income",
                period1Val = result.period1.totalIncome,
                period2Val = result.period2.totalIncome,
                deltaAmount = result.incomeDeltaAmount,
                deltaPercent = result.incomeDeltaPercent,
                currencySymbol = currencySymbol,
                isPositiveGood = true,
                modifier = Modifier.weight(1f)
            )

            // Expense KPI
            KpiDeltaCard(
                title = "Total Expenses",
                period1Val = result.period1.totalExpenses,
                period2Val = result.period2.totalExpenses,
                deltaAmount = result.expenseDeltaAmount,
                deltaPercent = result.expenseDeltaPercent,
                currencySymbol = currencySymbol,
                isPositiveGood = false, // Less expense is good
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Net Savings KPI
            KpiDeltaCard(
                title = "Net Savings",
                period1Val = result.period1.netSavings,
                period2Val = result.period2.netSavings,
                deltaAmount = result.netSavingsDeltaAmount,
                deltaPercent = result.netSavingsDeltaPercent,
                currencySymbol = currencySymbol,
                isPositiveGood = true,
                modifier = Modifier.weight(1f)
            )

            // Savings Rate KPI
            SavingsRateDeltaCard(
                period1Rate = result.period1.savingsRate,
                period2Rate = result.period2.savingsRate,
                rateDelta = result.savingsRateDelta,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun KpiDeltaCard(
    title: String,
    period1Val: Double,
    period2Val: Double,
    deltaAmount: Double,
    deltaPercent: Float,
    currencySymbol: String,
    isPositiveGood: Boolean,
    modifier: Modifier = Modifier
) {
    val isFavorable = if (isPositiveGood) deltaAmount >= 0 else deltaAmount <= 0
    val deltaColor = if (isFavorable) IncomeGreen else ExpenseRed

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = CurrencyFormatter.formatCompact(period1Val, currencySymbol),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Prior: ${CurrencyFormatter.formatCompact(period2Val, currencySymbol)}",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(2.dp))

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = deltaColor.copy(alpha = 0.12f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = if (deltaAmount >= 0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = deltaColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "${if (deltaPercent >= 0) "+" else ""}${"%.1f".format(deltaPercent)}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                        color = deltaColor
                    )
                }
            }
        }
    }
}

@Composable
private fun SavingsRateDeltaCard(
    period1Rate: Float,
    period2Rate: Float,
    rateDelta: Float,
    modifier: Modifier = Modifier
) {
    val isFavorable = rateDelta >= 0
    val deltaColor = if (isFavorable) IncomeGreen else ExpenseRed

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Savings Rate",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "${"%.1f".format(period1Rate)}%",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "Prior: ${"%.1f".format(period2Rate)}%",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(2.dp))

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = deltaColor.copy(alpha = 0.12f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = if (rateDelta >= 0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = deltaColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "${if (rateDelta >= 0) "+" else ""}${"%.1f".format(rateDelta)}% pts",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                        color = deltaColor
                    )
                }
            }
        }
    }
}

@Composable
private fun SideBySideComparisonChart(
    result: TimeFrameComparisonResult,
    currencySymbol: String
) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(result) {
        animProgress.snapTo(0f)
        animProgress.animateTo(1f, animationSpec = tween(650))
    }

    val maxAmount = maxOf(
        result.period1.totalIncome,
        result.period2.totalIncome,
        result.period1.totalExpenses,
        result.period2.totalExpenses,
        kotlin.math.abs(result.period1.netSavings),
        kotlin.math.abs(result.period2.netSavings),
        1.0
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Side-by-Side Comparison",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Income, Expenses & Net Cashflow comparison",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Dual Bar Chart Group
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // Group 1: Income
                DualBarMetricGroup(
                    title = "Income",
                    period1Val = result.period1.totalIncome,
                    period2Val = result.period2.totalIncome,
                    maxVal = maxAmount,
                    color1 = IncomeGreen,
                    color2 = IncomeGreen.copy(alpha = 0.5f),
                    currencySymbol = currencySymbol,
                    animProgress = animProgress.value
                )

                // Group 2: Expenses
                DualBarMetricGroup(
                    title = "Expenses",
                    period1Val = result.period1.totalExpenses,
                    period2Val = result.period2.totalExpenses,
                    maxVal = maxAmount,
                    color1 = ExpenseRed,
                    color2 = ExpenseRed.copy(alpha = 0.5f),
                    currencySymbol = currencySymbol,
                    animProgress = animProgress.value
                )

                // Group 3: Net Savings
                DualBarMetricGroup(
                    title = "Net Savings",
                    period1Val = result.period1.netSavings,
                    period2Val = result.period2.netSavings,
                    maxVal = maxAmount,
                    color1 = MaterialTheme.colorScheme.primary,
                    color2 = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                    currencySymbol = currencySymbol,
                    animProgress = animProgress.value
                )
            }

            // Legend Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
                    Text("Solid: Period 1 (Recent)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)))
                    Text("Muted: Period 2 (Prior)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun DualBarMetricGroup(
    title: String,
    period1Val: Double,
    period2Val: Double,
    maxVal: Double,
    color1: Color,
    color2: Color,
    currencySymbol: String,
    animProgress: Float
) {
    val h1 = ((period1Val.coerceAtLeast(0.0) / maxVal) * 120f * animProgress).toFloat().coerceIn(4f, 130f)
    val h2 = ((period2Val.coerceAtLeast(0.0) / maxVal) * 120f * animProgress).toFloat().coerceIn(4f, 130f)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom,
        modifier = Modifier.fillMaxHeight()
    ) {
        // Values at top
        Text(
            text = CurrencyFormatter.formatCompact(period1Val, currencySymbol),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Side-by-side bars
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Period 1 Bar
            Box(
                modifier = Modifier
                    .width(22.dp)
                    .height(h1.dp)
                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                    .background(color1)
            )

            // Period 2 Bar
            Box(
                modifier = Modifier
                    .width(22.dp)
                    .height(h2.dp)
                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                    .background(color2)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun CategoryAllocationComparisonCard(
    period1: PeriodStats,
    period2: PeriodStats,
    currencySymbol: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "53 / 24 / 23 Allocation Comparison",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Category 1: Bills
            AllocationRowCompare(
                name = "Bills (53% Target)",
                p1Amount = period1.billsTotal,
                p1Percent = period1.billsPercentage,
                p2Amount = period2.billsTotal,
                p2Percent = period2.billsPercentage,
                color = BillsColor,
                currencySymbol = currencySymbol
            )

            // Category 2: Lifestyle
            AllocationRowCompare(
                name = "Life Style (24% Target)",
                p1Amount = period1.lifestyleTotal,
                p1Percent = period1.lifestylePercentage,
                p2Amount = period2.lifestyleTotal,
                p2Percent = period2.lifestylePercentage,
                color = LifestyleColor,
                currencySymbol = currencySymbol
            )

            // Category 3: Debt & Savings
            AllocationRowCompare(
                name = "Debt & Savings (23% Target)",
                p1Amount = period1.debtSavingsTotal,
                p1Percent = period1.debtSavingsPercentage,
                p2Amount = period2.debtSavingsTotal,
                p2Percent = period2.debtSavingsPercentage,
                color = DebtSavingsColor,
                currencySymbol = currencySymbol
            )
        }
    }
}

@Composable
private fun AllocationRowCompare(
    name: String,
    p1Amount: Double,
    p1Percent: Float,
    p2Amount: Double,
    p2Percent: Float,
    color: Color,
    currencySymbol: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            val diff = p1Amount - p2Amount
            Text(
                text = "P1: ${CurrencyFormatter.formatCompact(p1Amount, currencySymbol)} (${p1Percent.toInt()}%) • P2: ${CurrencyFormatter.formatCompact(p2Amount, currencySymbol)} (${p2Percent.toInt()}%)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Dual progress bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // P1 Progress
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(color.copy(alpha = 0.2f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((p1Percent / 100f).coerceIn(0f, 1f))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(color)
                    )
                }
                Text("Period 1: ${"%.1f".format(p1Percent)}%", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = color, fontWeight = FontWeight.Bold)
            }

            // P2 Progress
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(color.copy(alpha = 0.15f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((p2Percent / 100f).coerceIn(0f, 1f))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(color.copy(alpha = 0.5f))
                    )
                }
                Text("Period 2: ${"%.1f".format(p2Percent)}%", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun MultiMonthTrajectoryCard(
    period1: PeriodStats,
    period2: PeriodStats,
    currencySymbol: String
) {
    val allPoints = (period2.monthlyBreakdown + period1.monthlyBreakdown).distinctBy { it.monthKey }.sortedBy { it.monthKey }
    val maxMonthlyVal = allPoints.maxOfOrNull { maxOf(it.income, it.expense, 1.0) } ?: 1.0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Monthly Progression Trajectory",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                allPoints.forEach { pt ->
                    val isP1 = pt.monthKey in period1.monthKeys
                    val incH = ((pt.income / maxMonthlyVal) * 90f).toFloat().coerceIn(3f, 95f)
                    val expH = ((pt.expense / maxMonthlyVal) * 90f).toFloat().coerceIn(3f, 95f)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        // Month status tag
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (isP1) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = if (isP1) "P1" else "P2",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                color = if (isP1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Bars
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                            verticalAlignment = Alignment.Bottom,
                            modifier = Modifier.height(100.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(14.dp)
                                    .height(incH.dp)
                                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                    .background(IncomeGreen)
                            )
                            Box(
                                modifier = Modifier
                                    .width(14.dp)
                                    .height(expH.dp)
                                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                    .background(ExpenseRed)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = pt.displayLabel,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = if (isP1) FontWeight.Bold else FontWeight.Normal,
                            color = if (isP1) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryVarianceRankCard(
    deltas: List<CategoryComparisonDelta>,
    currencySymbol: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Top Category Shifts",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${deltas.size} categories",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            deltas.take(6).forEach { item ->
                val isIncreased = item.deltaAmount > 0
                val deltaColor = if (isIncreased) ExpenseRed else IncomeGreen

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.categoryName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "P1: ${CurrencyFormatter.formatCompact(item.period1Amount, currencySymbol)} • P2: ${CurrencyFormatter.formatCompact(item.period2Amount, currencySymbol)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${if (isIncreased) "+" else ""}${CurrencyFormatter.formatCompact(item.deltaAmount, currencySymbol)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = deltaColor
                        )
                        Text(
                            text = "${if (item.deltaPercent >= 0) "+" else ""}${"%.1f".format(item.deltaPercent)}%",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            color = deltaColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthDropdownSelector(
    label: String,
    selectedMonth: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.primary)
                Text(
                    DateUtils.formatDisplayMonth(selectedMonth),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { mKey ->
                DropdownMenuItem(
                    text = { Text(DateUtils.formatDisplayMonth(mKey), fontWeight = if (mKey == selectedMonth) FontWeight.Bold else FontWeight.Normal) },
                    onClick = {
                        onSelect(mKey)
                        expanded = false
                    }
                )
            }
        }
    }
}
