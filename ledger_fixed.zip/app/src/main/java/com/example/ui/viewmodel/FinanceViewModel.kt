package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AccountabilityRuleEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.FuturePlanEntity
import com.example.data.model.MonthlySummary
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.FinanceRepository
import com.example.ui.theme.AppTheme
import com.example.util.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenTab(val title: String) {
    OVERVIEW("Overview"),
    TRANSACTIONS("Transactions"),
    PLANS("Future Plans"),
    ANALYTICS("Analytics"),
    ACCOUNTABILITY("Rules & Mantras"),
    SYNC_SETTINGS("Sync & Settings")
}

data class FilterState(
    val categoryGroup: CategoryGroup? = null,
    val searchQuery: String = "",
    val selectedTag: String = "",
    val showUnpaidOnly: Boolean = false
)

class FinanceViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FinanceRepository

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = FinanceRepository(
            db.transactionDao(),
            db.budgetSettingDao(),
            db.accountabilityDao(),
            db.planDao()
        )
    }

    private val _selectedMonth = MutableStateFlow(DateUtils.currentMonthKey())
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    private val _appTheme = MutableStateFlow(AppTheme.PIXEL)
    val appTheme: StateFlow<AppTheme> = _appTheme.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _currentTab = MutableStateFlow(ScreenTab.OVERVIEW)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    private val _currencySymbol = MutableStateFlow("৳")
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    private val _snackbarEvent = MutableSharedFlow<String>()
    val snackbarEvent: SharedFlow<String> = _snackbarEvent.asSharedFlow()

    // Dialog & Sheet States
    private val _editingTransaction = MutableStateFlow<TransactionEntity?>(null)
    val editingTransaction: StateFlow<TransactionEntity?> = _editingTransaction.asStateFlow()

    private val _showAddTransactionSheet = MutableStateFlow(false)
    val showAddTransactionSheet: StateFlow<Boolean> = _showAddTransactionSheet.asStateFlow()

    private val _showDailyRateDialog = MutableStateFlow(false)
    val showDailyRateDialog: StateFlow<Boolean> = _showDailyRateDialog.asStateFlow()

    private val _showAddRuleDialog = MutableStateFlow(false)
    val showAddRuleDialog: StateFlow<Boolean> = _showAddRuleDialog.asStateFlow()

    private val _showBudgetSettingsDialog = MutableStateFlow(false)
    val showBudgetSettingsDialog: StateFlow<Boolean> = _showBudgetSettingsDialog.asStateFlow()

    private val _showSyncDialog = MutableStateFlow(false)
    val showSyncDialog: StateFlow<Boolean> = _showSyncDialog.asStateFlow()

    // Multi-Month Plans States
    private val _editingPlan = MutableStateFlow<FuturePlanEntity?>(null)
    val editingPlan: StateFlow<FuturePlanEntity?> = _editingPlan.asStateFlow()

    private val _showAddPlanDialog = MutableStateFlow(false)
    val showAddPlanDialog: StateFlow<Boolean> = _showAddPlanDialog.asStateFlow()

    // Calculator Dialog States
    private val _showCalculatorDialog = MutableStateFlow(false)
    val showCalculatorDialog: StateFlow<Boolean> = _showCalculatorDialog.asStateFlow()

    private val _calculatorInitialExpression = MutableStateFlow("")
    val calculatorInitialExpression: StateFlow<String> = _calculatorInitialExpression.asStateFlow()

    // Google Sync status (simulated real state for cross-device readiness)
    private val _googleAccount = MutableStateFlow<String?>("ibrahimakash17@gmail.com")
    val googleAccount: StateFlow<String?> = _googleAccount.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncedTime = MutableStateFlow(System.currentTimeMillis())
    val lastSyncedTime: StateFlow<Long> = _lastSyncedTime.asStateFlow()

    // Reactive streams
    @OptIn(ExperimentalCoroutinesApi::class)
    val monthlyTransactions: StateFlow<List<TransactionEntity>> = _selectedMonth
        .flatMapLatest { monthKey ->
            repository.getTransactionsForMonth(monthKey)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        monthlyTransactions,
        _filterState
    ) { transactions, filter ->
        transactions.filter { tx ->
            val matchesGroup = filter.categoryGroup == null || tx.categoryGroup == filter.categoryGroup
            val matchesSearch = filter.searchQuery.isBlank() ||
                    tx.title.contains(filter.searchQuery, ignoreCase = true) ||
                    tx.categoryName.contains(filter.searchQuery, ignoreCase = true) ||
                    tx.tags.contains(filter.searchQuery, ignoreCase = true) ||
                    tx.notes.contains(filter.searchQuery, ignoreCase = true)
            val matchesTag = filter.selectedTag.isBlank() || tx.tags.contains(filter.selectedTag, ignoreCase = true)
            val matchesUnpaid = !filter.showUnpaidOnly || !tx.isPaid

            matchesGroup && matchesSearch && matchesTag && matchesUnpaid
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val monthlySummary: StateFlow<MonthlySummary> = _selectedMonth
        .flatMapLatest { monthKey ->
            repository.getMonthlySummary(monthKey)
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            MonthlySummary(
                monthYearKey = DateUtils.currentMonthKey(),
                baseIncome = 0.0,
                dailyRateIncome = 0.0,
                extraIncome = 0.0,
                totalIncome = 0.0,
                billsTotal = 0.0,
                lifestyleTotal = 0.0,
                debtAndSavingsTotal = 0.0,
                totalExpenses = 0.0,
                netBalance = 0.0,
                extraBuffer = 0.0,
                billsPercentage = 0f,
                lifestylePercentage = 0f,
                debtSavingsPercentage = 0f
            )
        )

    val budgetSettings: StateFlow<List<BudgetSettingEntity>> = repository.getBudgetSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accountabilityRules: StateFlow<List<AccountabilityRuleEntity>> = repository.getAccountabilityRules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val plans: StateFlow<List<FuturePlanEntity>> = repository.getAllPlans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun setMonth(monthKey: String) {
        _selectedMonth.value = monthKey
    }

    fun previousMonth() {
        _selectedMonth.value = DateUtils.getPreviousMonth(_selectedMonth.value)
    }

    fun nextMonth() {
        _selectedMonth.value = DateUtils.getNextMonth(_selectedMonth.value)
    }

    fun setCurrency(symbol: String) {
        _currencySymbol.value = symbol
    }

    fun setAppTheme(theme: AppTheme) {
        _appTheme.value = theme
    }

    fun setDarkTheme(isDark: Boolean) {
        _isDarkTheme.value = isDark
    }

    fun updateFilter(update: (FilterState) -> FilterState) {
        _filterState.value = update(_filterState.value)
    }

    fun openAddTransactionSheet(transaction: TransactionEntity? = null) {
        _editingTransaction.value = transaction
        _showAddTransactionSheet.value = true
    }

    fun closeAddTransactionSheet() {
        _editingTransaction.value = null
        _showAddTransactionSheet.value = false
    }

    fun openDailyRateDialog() {
        _showDailyRateDialog.value = true
    }

    fun closeDailyRateDialog() {
        _showDailyRateDialog.value = false
    }

    fun openAddRuleDialog() {
        _showAddRuleDialog.value = true
    }

    fun closeAddRuleDialog() {
        _showAddRuleDialog.value = false
    }

    fun openBudgetSettingsDialog() {
        _showBudgetSettingsDialog.value = true
    }

    fun closeBudgetSettingsDialog() {
        _showBudgetSettingsDialog.value = false
    }

    fun openSyncDialog() {
        _showSyncDialog.value = true
    }

    fun closeSyncDialog() {
        _showSyncDialog.value = false
    }

    fun openAddPlanDialog(plan: FuturePlanEntity? = null) {
        _editingPlan.value = plan
        _showAddPlanDialog.value = true
    }

    fun closeAddPlanDialog() {
        _editingPlan.value = null
        _showAddPlanDialog.value = false
    }

    fun openCalculator(initialExpression: String = "") {
        _calculatorInitialExpression.value = initialExpression
        _showCalculatorDialog.value = true
    }

    fun closeCalculator() {
        _showCalculatorDialog.value = false
    }

    fun savePlan(plan: FuturePlanEntity) {
        viewModelScope.launch {
            repository.addOrUpdatePlan(plan)
            closeAddPlanDialog()
            _snackbarEvent.emit("Roadmap updated: ${plan.title}")
        }
    }

    fun deletePlan(plan: FuturePlanEntity) {
        viewModelScope.launch {
            repository.deletePlan(plan)
            closeAddPlanDialog()
            _snackbarEvent.emit("Roadmap deleted: ${plan.title}")
        }
    }

    fun recordPlanInstallment(plan: FuturePlanEntity) {
        viewModelScope.launch {
            val tx = repository.recordPlanPayment(plan, _selectedMonth.value)
            _snackbarEvent.emit("Payment of ৳${plan.monthlyInstallmentAmount.toInt()} recorded in ${_selectedMonth.value} ledger!")
        }
    }

    fun saveTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.addOrUpdateTransaction(transaction)
            closeAddTransactionSheet()
            _snackbarEvent.emit("Saved: ${transaction.title}")
        }
    }

    fun togglePaidStatus(transaction: TransactionEntity) {
        viewModelScope.launch {
            val updated = transaction.copy(isPaid = !transaction.isPaid)
            repository.addOrUpdateTransaction(updated)
            _snackbarEvent.emit(if (updated.isPaid) "Marked as Paid" else "Marked as Unpaid")
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            _snackbarEvent.emit("Deleted: ${transaction.title}")
        }
    }

    fun saveBudgetSetting(group: CategoryGroup, percent: Float) {
        viewModelScope.launch {
            repository.saveBudgetSetting(BudgetSettingEntity(group, percent))
            _snackbarEvent.emit("Updated budget for ${group.displayName}")
        }
    }

    fun addRule(title: String, content: String, category: String) {
        viewModelScope.launch {
            repository.addRule(
                AccountabilityRuleEntity(
                    title = title,
                    content = content,
                    category = category,
                    isPinned = true
                )
            )
            closeAddRuleDialog()
            _snackbarEvent.emit("Rule added")
        }
    }

    fun toggleRulePin(rule: AccountabilityRuleEntity) {
        viewModelScope.launch {
            repository.updateRule(rule.copy(isPinned = !rule.isPinned))
        }
    }

    fun deleteRule(rule: AccountabilityRuleEntity) {
        viewModelScope.launch {
            repository.deleteRule(rule)
            _snackbarEvent.emit("Rule deleted")
        }
    }

    fun populateStandardTemplate() {
        viewModelScope.launch {
            repository.populateTemplateForMonth(_selectedMonth.value)
            _snackbarEvent.emit("Standard monthly budget template applied!")
        }
    }

    fun performGoogleSync() {
        viewModelScope.launch {
            _isSyncing.value = true
            kotlinx.coroutines.delay(1200) // Realistic cloud sync feedback
            _lastSyncedTime.value = System.currentTimeMillis()
            _isSyncing.value = false
            _snackbarEvent.emit("All financial records synced with Google Account (${_googleAccount.value})")
        }
    }

    fun setGoogleAccount(email: String?) {
        _googleAccount.value = email
    }

    fun exportBackupJson(callback: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportDataAsJson(allTransactions.value, accountabilityRules.value)
            callback(json)
        }
    }

    fun importBackupJson(jsonStr: String) {
        viewModelScope.launch {
            val success = repository.importDataFromJson(jsonStr)
            if (success) {
                _snackbarEvent.emit("Backup restored successfully!")
            } else {
                _snackbarEvent.emit("Failed to import backup JSON format.")
            }
        }
    }
}

