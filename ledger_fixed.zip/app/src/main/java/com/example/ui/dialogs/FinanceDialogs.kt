package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.BillsColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LifestyleColor
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils

@Composable
fun DailyRateCalculatorDialog(
    monthKey: String,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onApplyToLedger: (TransactionEntity) -> Unit
) {
    var baseSalaryInput by remember { mutableStateOf("39520") }
    var dailyRateInput by remember { mutableStateOf("400") }
    var daysWorkedInput by remember { mutableStateOf("21") }

    val baseSalary = baseSalaryInput.toDoubleOrNull() ?: 0.0
    val dailyRate = dailyRateInput.toDoubleOrNull() ?: 0.0
    val daysWorked = daysWorkedInput.toDoubleOrNull() ?: 0.0

    val dailyEarnings = dailyRate * daysWorked
    val totalNetIncome = baseSalary + dailyEarnings

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Daily Rate & Earning Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Calculate subtotal earnings using your formula: Base + (Rate × Days)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = baseSalaryInput,
                    onValueChange = { baseSalaryInput = it },
                    label = { Text("Base Salary") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dailyRateInput,
                        onValueChange = { dailyRateInput = it },
                        label = { Text("Daily Rate (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = daysWorkedInput,
                        onValueChange = { daysWorkedInput = it },
                        label = { Text("Days (e.g. 21)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Computation Result Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = IncomeGreen.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Daily Rate Total: ${CurrencyFormatter.format(dailyEarnings, currencySymbol)} (${daysWorked.toInt()} days @ ${dailyRate.toInt()}৳)",
                            style = MaterialTheme.typography.labelSmall,
                            color = IncomeGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Total Sub Income: ${CurrencyFormatter.format(totalNetIncome, currencySymbol)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = IncomeGreen
                        )
                        Text(
                            text = "Formula: ${baseSalary.toInt()} + (${dailyRate.toInt()}*${daysWorked.toInt()}) = ${totalNetIncome.toInt()}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val tx = TransactionEntity(
                        title = "Daily Working Rate (${daysWorked.toInt()} days)",
                        amount = dailyEarnings,
                        expression = "${dailyRate.toInt()}*${daysWorked.toInt()}",
                        type = TransactionType.INCOME,
                        categoryGroup = CategoryGroup.INCOME_BASE,
                        categoryName = "Daily Allowance",
                        monthYearKey = monthKey,
                        dateMillis = System.currentTimeMillis(),
                        paymentAccount = "Bank Account",
                        tags = "DailyAllowance,${daysWorked.toInt()}Days",
                        notes = "${dailyRate.toInt()}৳ per day for ${daysWorked.toInt()} days"
                    )
                    onApplyToLedger(tx)
                },
                modifier = Modifier.testTag("apply_daily_rate_button")
            ) {
                Text("Add to Ledger")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddRuleDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, content: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Rule") }

    val presetRules = listOf(
        "Colleagues are not friends.",
        "Dont share personal finance or other info with them.",
        "They are more loyal to them than you.",
        "Meghna theke 2 bkash A/C use kore bill pay korle 200 taka charge jabe."
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Rule, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Add Financial Accountability Rule", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title / Summary") },
                    placeholder = { Text("e.g. Finance Boundary") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Rule / Note Description") },
                    placeholder = { Text("e.g. Don't share personal finance with colleagues...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )

                // Category selector
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Rule", "Warning", "Principle").forEach { cat ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (category == cat) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Transparent)
                        ) {
                            TextButton(onClick = { category = cat }) {
                                Text(cat, fontWeight = if (category == cat) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (content.isNotBlank()) {
                        onAdd(title.ifBlank { category }, content, category)
                    }
                },
                enabled = content.isNotBlank()
            ) {
                Text("Save Rule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun BudgetSettingsDialog(
    settings: List<BudgetSettingEntity>,
    onDismiss: () -> Unit,
    onSave: (bills: Float, lifestyle: Float, debt: Float) -> Unit
) {
    var billsPercent by remember {
        mutableFloatStateOf(settings.find { it.groupType == CategoryGroup.BILLS }?.targetPercentage ?: 53f)
    }
    var lifestylePercent by remember {
        mutableFloatStateOf(settings.find { it.groupType == CategoryGroup.LIFESTYLE }?.targetPercentage ?: 24f)
    }
    var debtPercent by remember {
        mutableFloatStateOf(settings.find { it.groupType == CategoryGroup.DEBT_AND_SAVINGS }?.targetPercentage ?: 23f)
    }

    val total = billsPercent + lifestylePercent + debtPercent

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Configure Budget Allocations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Customize your target expense distribution (Default: 53% Bills, 24% Life Style, 23% Debt & Savings)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Bills Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("1. Bills", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = BillsColor)
                        Text("${billsPercent.toInt()}%", fontWeight = FontWeight.Bold, color = BillsColor)
                    }
                    Slider(
                        value = billsPercent,
                        onValueChange = { billsPercent = it },
                        valueRange = 0f..100f,
                        steps = 99
                    )
                }

                // Lifestyle Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("2. Life Style", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = LifestyleColor)
                        Text("${lifestylePercent.toInt()}%", fontWeight = FontWeight.Bold, color = LifestyleColor)
                    }
                    Slider(
                        value = lifestylePercent,
                        onValueChange = { lifestylePercent = it },
                        valueRange = 0f..100f,
                        steps = 99
                    )
                }

                // Debt Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("3. Debt & Savings", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = DebtSavingsColor)
                        Text("${debtPercent.toInt()}%", fontWeight = FontWeight.Bold, color = DebtSavingsColor)
                    }
                    Slider(
                        value = debtPercent,
                        onValueChange = { debtPercent = it },
                        valueRange = 0f..100f,
                        steps = 99
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (total.toInt() == 100) IncomeGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Total Allocation: ${total.toInt()}% ${if (total.toInt() == 100) "(Balanced 100%)" else "(Must equal 100%)"}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (total.toInt() == 100) IncomeGreen else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(billsPercent, lifestylePercent, debtPercent) }
            ) {
                Text("Save Targets")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun GoogleSyncDialog(
    googleAccount: String?,
    isSyncing: Boolean,
    lastSyncedTime: Long,
    onSyncNow: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Google Account Cloud Sync", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Color.White)
                        }
                        Column {
                            Text("Connected Google Account", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(googleAccount ?: "ibrahimakash17@gmail.com", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Last synced: ${DateUtils.formatDate(lastSyncedTime)} ${DateUtils.formatTime(lastSyncedTime)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Text(
                    text = "Seamless cloud sync is active across all your Android devices. Your expenses, earnings, formulas, budget percentages, and accountability notes are encrypted and backed up.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onSyncNow,
                enabled = !isSyncing
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Syncing...")
                } else {
                    Icon(Icons.Default.CloudDone, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sync Now")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
