package com.example.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryGroup
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.BillsColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LifestyleColor
import com.example.util.CurrencyFormatter
import com.example.util.DateUtils
import com.example.util.ExpressionEvaluator

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTransactionSheet(
    initialTransaction: TransactionEntity?,
    monthKey: String,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit,
    onDelete: ((TransactionEntity) -> Unit)? = null
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var type by remember { mutableStateOf(initialTransaction?.type ?: TransactionType.EXPENSE) }
    var title by remember { mutableStateOf(initialTransaction?.title ?: "") }
    var expressionInput by remember { mutableStateOf(initialTransaction?.expression ?: (initialTransaction?.amount?.toString() ?: "")) }
    var categoryGroup by remember { mutableStateOf(initialTransaction?.categoryGroup ?: CategoryGroup.BILLS) }
    var categoryName by remember { mutableStateOf(initialTransaction?.categoryName ?: "") }
    var plannedAmountInput by remember { mutableStateOf(initialTransaction?.plannedAmount?.toString() ?: "") }
    var paymentAccount by remember { mutableStateOf(initialTransaction?.paymentAccount ?: "Cash") }
    var tagsInput by remember { mutableStateOf(initialTransaction?.tags ?: "") }
    var notesInput by remember { mutableStateOf(initialTransaction?.notes ?: "") }
    var isPaid by remember { mutableStateOf(initialTransaction?.isPaid ?: true) }

    // Live computed amount from arithmetic expression
    val calculatedAmount = remember(expressionInput) {
        ExpressionEvaluator.evaluate(expressionInput) ?: 0.0
    }

    val quickExpenseTitles = listOf(
        "Home", "Rent", "Health", "Electricity", "Internet",
        "Khulna", "Mim", "Pocket Money",
        "Debt 1", "Debt 2", "Card", "DPS", "DPS 2", "MTB Payment", "Meghna Payment"
    )

    val quickIncomeTitles = listOf(
        "Base Salary", "Daily Working Rate", "Extra Income", "Freelance", "Bonus"
    )

    val paymentAccounts = listOf("Cash", "bKash", "MTB Bank", "Meghna Bank", "Credit Card", "Bank Transfer")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialTransaction == null) "Add Transaction" else "Edit Transaction",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            // Income / Expense Tab selector
            TabRow(
                selectedTabIndex = if (type == TransactionType.INCOME) 0 else 1,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Tab(
                    selected = type == TransactionType.INCOME,
                    onClick = {
                        type = TransactionType.INCOME
                        if (categoryGroup == CategoryGroup.BILLS || categoryGroup == CategoryGroup.LIFESTYLE || categoryGroup == CategoryGroup.DEBT_AND_SAVINGS) {
                            categoryGroup = CategoryGroup.INCOME_BASE
                        }
                    },
                    text = { Text("Income", color = if (type == TransactionType.INCOME) IncomeGreen else MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.testTag("type_income_tab")
                )
                Tab(
                    selected = type == TransactionType.EXPENSE,
                    onClick = {
                        type = TransactionType.EXPENSE
                        if (categoryGroup == CategoryGroup.INCOME_BASE || categoryGroup == CategoryGroup.INCOME_EXTRA) {
                            categoryGroup = CategoryGroup.BILLS
                        }
                    },
                    text = { Text("Expense", color = if (type == TransactionType.EXPENSE) ExpenseRed else MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.testTag("type_expense_tab")
                )
            }

            // Amount / Expression input with live preview
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(
                    value = expressionInput,
                    onValueChange = { expressionInput = it },
                    label = { Text("Amount or Formula (e.g., 3500+3260 or 400*21)") },
                    placeholder = { Text("0.00") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    leadingIcon = {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    trailingIcon = {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (type == TransactionType.EXPENSE) ExpenseRed.copy(alpha = 0.15f) else IncomeGreen.copy(alpha = 0.15f),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "= ${CurrencyFormatter.format(calculatedAmount, currencySymbol)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (type == TransactionType.EXPENSE) ExpenseRed else IncomeGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transaction_amount_input")
                )
            }

            // Title input
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title / Item Name") },
                placeholder = { Text("e.g. Rent, Health, Internet, Khulna...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transaction_title_input")
            )

            // Quick suggestion chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val suggestions = if (type == TransactionType.INCOME) quickIncomeTitles else quickExpenseTitles
                suggestions.forEach { suggestion ->
                    FilterChip(
                        selected = title.equals(suggestion, ignoreCase = true),
                        onClick = {
                            title = suggestion
                            if (categoryName.isBlank()) categoryName = suggestion
                            // Auto map groups
                            when (suggestion) {
                                "Home", "Rent", "Health", "Electricity", "Internet" -> categoryGroup = CategoryGroup.BILLS
                                "Khulna", "Mim", "Pocket Money" -> categoryGroup = CategoryGroup.LIFESTYLE
                                "Debt 1", "Debt 2", "Card", "DPS", "DPS 2", "MTB Payment", "Meghna Payment" -> categoryGroup = CategoryGroup.DEBT_AND_SAVINGS
                                "Base Salary", "Daily Working Rate" -> categoryGroup = CategoryGroup.INCOME_BASE
                                "Extra Income" -> categoryGroup = CategoryGroup.INCOME_EXTRA
                            }
                        },
                        label = { Text(suggestion, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            // Category Group Selector
            Text("Category Group", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (type == TransactionType.EXPENSE) {
                    FilterChip(
                        selected = categoryGroup == CategoryGroup.BILLS,
                        onClick = { categoryGroup = CategoryGroup.BILLS },
                        label = { Text("1. Bills (53%)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BillsColor.copy(alpha = 0.2f),
                            selectedLabelColor = BillsColor
                        )
                    )
                    FilterChip(
                        selected = categoryGroup == CategoryGroup.LIFESTYLE,
                        onClick = { categoryGroup = CategoryGroup.LIFESTYLE },
                        label = { Text("2. Life Style (24%)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LifestyleColor.copy(alpha = 0.2f),
                            selectedLabelColor = LifestyleColor
                        )
                    )
                    FilterChip(
                        selected = categoryGroup == CategoryGroup.DEBT_AND_SAVINGS,
                        onClick = { categoryGroup = CategoryGroup.DEBT_AND_SAVINGS },
                        label = { Text("3. Debt & Savings (23%)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = DebtSavingsColor.copy(alpha = 0.2f),
                            selectedLabelColor = DebtSavingsColor
                        )
                    )
                } else {
                    FilterChip(
                        selected = categoryGroup == CategoryGroup.INCOME_BASE,
                        onClick = { categoryGroup = CategoryGroup.INCOME_BASE },
                        label = { Text("Base Income") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IncomeGreen.copy(alpha = 0.2f),
                            selectedLabelColor = IncomeGreen
                        )
                    )
                    FilterChip(
                        selected = categoryGroup == CategoryGroup.INCOME_EXTRA,
                        onClick = { categoryGroup = CategoryGroup.INCOME_EXTRA },
                        label = { Text("Extra Income") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IncomeGreen.copy(alpha = 0.2f),
                            selectedLabelColor = IncomeGreen
                        )
                    )
                }
            }

            // Planned vs Actual (Optional for Expenses)
            if (type == TransactionType.EXPENSE) {
                OutlinedTextField(
                    value = plannedAmountInput,
                    onValueChange = { plannedAmountInput = it },
                    label = { Text("Planned / Budget Amount (Optional)") },
                    placeholder = { Text("e.g. 4500 (actual was 5026)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Payment Account
            Text("Payment Account", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                paymentAccounts.forEach { acc ->
                    FilterChip(
                        selected = paymentAccount == acc,
                        onClick = { paymentAccount = acc },
                        label = { Text(acc, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            // Tags
            OutlinedTextField(
                value = tagsInput,
                onValueChange = { tagsInput = it },
                label = { Text("Tags (comma-separated)") },
                placeholder = { Text("e.g. Rent, Health, Khulna, DPS") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Notes + Charge alert quick paste
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Notes / Warnings") },
                    placeholder = { Text("e.g. Meghna bkash charge 200 taka") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                // Quick warning template chip
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            notesInput = "Meghna theke 2 bkash A/C use kore bill pay korle 200 taka charge jabe."
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(12.dp))
                        Text(
                            "Insert: Meghna -> bKash 200৳ fee rule note",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Save & Delete buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (initialTransaction != null && onDelete != null) {
                    OutlinedButton(
                        onClick = { onDelete(initialTransaction) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("delete_transaction_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete")
                    }
                }

                Button(
                    onClick = {
                        val finalTitle = title.ifBlank { "Untitled ${if (type == TransactionType.INCOME) "Income" else "Expense"}" }
                        val plannedAmt = plannedAmountInput.toDoubleOrNull()
                        val tx = (initialTransaction?.copy(
                            title = finalTitle,
                            amount = calculatedAmount,
                            expression = expressionInput,
                            type = type,
                            categoryGroup = categoryGroup,
                            categoryName = categoryName.ifBlank { finalTitle },
                            paymentAccount = paymentAccount,
                            tags = tagsInput,
                            notes = notesInput,
                            isPaid = isPaid,
                            plannedAmount = plannedAmt
                        ) ?: TransactionEntity(
                            title = finalTitle,
                            amount = calculatedAmount,
                            expression = expressionInput,
                            type = type,
                            categoryGroup = categoryGroup,
                            categoryName = categoryName.ifBlank { finalTitle },
                            monthYearKey = monthKey,
                            paymentAccount = paymentAccount,
                            tags = tagsInput,
                            notes = notesInput,
                            isPaid = isPaid,
                            plannedAmount = plannedAmt
                        ))
                        onSave(tx)
                    },
                    modifier = Modifier
                        .weight(2f)
                        .testTag("save_transaction_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (type == TransactionType.INCOME) IncomeGreen else ExpenseRed
                    )
                ) {
                    Text("Save ${CurrencyFormatter.format(calculatedAmount, currencySymbol)}", style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
