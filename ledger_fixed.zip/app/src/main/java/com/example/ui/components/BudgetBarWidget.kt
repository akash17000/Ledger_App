package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.MonthlySummary
import com.example.ui.theme.BillsColor
import com.example.ui.theme.BillsContainerColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.DebtSavingsContainerColor
import com.example.ui.theme.LifestyleColor
import com.example.ui.theme.LifestyleContainerColor
import com.example.util.CurrencyFormatter

@Composable
fun BudgetAllocationOverview(
    summary: MonthlySummary,
    budgetSettings: List<BudgetSettingEntity>,
    currencySymbol: String,
    onCategoryClick: (CategoryGroup) -> Unit,
    onConfigureBudget: () -> Unit,
    modifier: Modifier = Modifier
) {
    val billsTarget = budgetSettings.find { it.groupType == CategoryGroup.BILLS }?.targetPercentage ?: 53f
    val lifestyleTarget = budgetSettings.find { it.groupType == CategoryGroup.LIFESTYLE }?.targetPercentage ?: 24f
    val debtTarget = budgetSettings.find { it.groupType == CategoryGroup.DEBT_AND_SAVINGS }?.targetPercentage ?: 23f

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BUDGET DISTRIBUTION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Target vs Actual Expense Allocation",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onConfigureBudget,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Configure Budget Targets",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // 1. Bills Group (53%)
            CategoryBudgetRow(
                name = "Fixed Bills",
                subtitle = "Home, Rent, Health, Utils",
                targetPercent = billsTarget,
                actualPercent = summary.billsPercentage,
                actualAmount = summary.billsTotal,
                currencySymbol = currencySymbol,
                accentColor = BillsColor,
                iconContainerColor = BillsContainerColor,
                icon = Icons.Default.ReceiptLong,
                onClick = { onCategoryClick(CategoryGroup.BILLS) }
            )

            // 2. Life Style Group (24%)
            CategoryBudgetRow(
                name = "Lifestyle",
                subtitle = "Khulna, Mim, Travel, Pocket",
                targetPercent = lifestyleTarget,
                actualPercent = summary.lifestylePercentage,
                actualAmount = summary.lifestyleTotal,
                currencySymbol = currencySymbol,
                accentColor = LifestyleColor,
                iconContainerColor = LifestyleContainerColor,
                icon = Icons.Default.CreditCard,
                onClick = { onCategoryClick(CategoryGroup.LIFESTYLE) }
            )

            // 3. Debt and Savings Group (23%)
            CategoryBudgetRow(
                name = "Debt & Savings",
                subtitle = "DPS, MTB, Meghna, Card",
                targetPercent = debtTarget,
                actualPercent = summary.debtSavingsPercentage,
                actualAmount = summary.debtAndSavingsTotal,
                currencySymbol = currencySymbol,
                accentColor = DebtSavingsColor,
                iconContainerColor = DebtSavingsContainerColor,
                icon = Icons.Default.AccountBalance,
                onClick = { onCategoryClick(CategoryGroup.DEBT_AND_SAVINGS) }
            )
        }
    }
}

@Composable
fun CategoryBudgetRow(
    name: String,
    subtitle: String,
    targetPercent: Float,
    actualPercent: Float,
    actualAmount: Double,
    currencySymbol: String,
    accentColor: Color,
    iconContainerColor: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val progress = if (targetPercent > 0) (actualPercent / 100f).coerceIn(0f, 1f) else 0f
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "ProgressAnim")
    val isOverBudget = actualPercent > (targetPercent + 2f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Icon in colored container
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconContainerColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${targetPercent.toInt()}% target  •  ${"%.1f".format(actualPercent)}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = if (isOverBudget) MaterialTheme.colorScheme.error else accentColor
                    )
                }

                // Progress track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = CurrencyFormatter.format(actualAmount, currencySymbol),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

