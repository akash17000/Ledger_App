package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.CategoryGroup
import com.example.data.model.PlanType
import com.example.data.model.TransactionType

/**
 * Room cannot persist Kotlin enums on its own — it needs an explicit
 * TypeConverter telling it how to turn each enum into a column value
 * (a String) and back. Without this class, the project fails to build:
 * KSP throws "Cannot figure out how to save this field into database"
 * for every enum-typed column (TransactionEntity.type/categoryGroup,
 * BudgetSettingEntity.groupType, FuturePlanEntity.planType/categoryGroup).
 */
class Converters {
    @TypeConverter
    fun fromTransactionType(value: TransactionType): String = value.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType = TransactionType.valueOf(value)

    @TypeConverter
    fun fromCategoryGroup(value: CategoryGroup): String = value.name

    @TypeConverter
    fun toCategoryGroup(value: String): CategoryGroup = CategoryGroup.valueOf(value)

    @TypeConverter
    fun fromPlanType(value: PlanType): String = value.name

    @TypeConverter
    fun toPlanType(value: String): PlanType = PlanType.valueOf(value)
}
