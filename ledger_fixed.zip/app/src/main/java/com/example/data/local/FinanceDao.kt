package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AccountabilityRuleEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.FuturePlanEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE monthYearKey = :monthKey ORDER BY dateMillis DESC, id DESC")
    fun getTransactionsForMonth(monthKey: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC, id DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE reminderDateMillis IS NOT NULL ORDER BY reminderDateMillis ASC")
    fun getUpcomingReminders(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<TransactionEntity>)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions WHERE monthYearKey = :monthKey")
    suspend fun deleteMonthTransactions(monthKey: String)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun getTransactionCount(): Int
}

@Dao
interface BudgetSettingDao {
    @Query("SELECT * FROM budget_settings")
    fun getAllBudgetSettings(): Flow<List<BudgetSettingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSetting(setting: BudgetSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(settings: List<BudgetSettingEntity>)

    @Query("SELECT COUNT(*) FROM budget_settings")
    suspend fun getCount(): Int
}

@Dao
interface AccountabilityDao {
    @Query("SELECT * FROM accountability_rules ORDER BY isPinned DESC, id ASC")
    fun getAllRules(): Flow<List<AccountabilityRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AccountabilityRuleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<AccountabilityRuleEntity>)

    @Update
    suspend fun updateRule(rule: AccountabilityRuleEntity)

    @Delete
    suspend fun deleteRule(rule: AccountabilityRuleEntity)

    @Query("SELECT COUNT(*) FROM accountability_rules")
    suspend fun getCount(): Int
}

@Dao
interface PlanDao {
    @Query("SELECT * FROM future_plans ORDER BY isCompleted ASC, createdAtMillis DESC")
    fun getAllPlans(): Flow<List<FuturePlanEntity>>

    @Query("SELECT * FROM future_plans WHERE id = :id")
    suspend fun getPlanById(id: Long): FuturePlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: FuturePlanEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(plans: List<FuturePlanEntity>)

    @Update
    suspend fun updatePlan(plan: FuturePlanEntity)

    @Delete
    suspend fun deletePlan(plan: FuturePlanEntity)

    @Query("DELETE FROM future_plans WHERE id = :id")
    suspend fun deletePlanById(id: Long)

    @Query("SELECT COUNT(*) FROM future_plans")
    suspend fun getCount(): Int
}

