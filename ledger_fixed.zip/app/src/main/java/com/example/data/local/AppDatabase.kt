package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AccountabilityRuleEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.FuturePlanEntity
import com.example.data.model.PlanType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TransactionEntity::class,
        BudgetSettingEntity::class,
        AccountabilityRuleEntity::class,
        FuturePlanEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetSettingDao(): BudgetSettingDao
    abstract fun accountabilityDao(): AccountabilityDao
    abstract fun planDao(): PlanDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ledgertrack_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                // Also trigger a safe population check to ensure data is always present after schema migrations
                scope.launch(Dispatchers.IO) {
                    try {
                        ensureInitialDataPopulated(instance)
                    } catch (_: Exception) {
                    }
                }
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                INSTANCE?.let { database ->
                    try {
                        populateInitialData(database)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}

suspend fun ensureInitialDataPopulated(database: AppDatabase) {
    val budgetDao = database.budgetSettingDao()
    val planDao = database.planDao()
    val accountabilityDao = database.accountabilityDao()
    val transactionDao = database.transactionDao()

    if (budgetDao.getCount() == 0 || transactionDao.getTransactionCount() == 0) {
        populateInitialData(database)
    } else {
        // If plans table is empty (e.g. upgraded from v1), populate default plans
        if (planDao.getCount() == 0) {
            val currentMonthKey = DateUtils.currentMonthKey()
            val initialPlans = listOf(
                FuturePlanEntity(
                    title = "Meghna Bank Clearance (Debt 1)",
                    planType = PlanType.DEBT_REPAYMENT,
                    totalTargetAmount = 30000.0,
                    monthlyInstallmentAmount = 7500.0,
                    startMonthKey = currentMonthKey,
                    durationMonths = 4,
                    paidAmount = 7500.0,
                    categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                    categoryName = "Debt 1",
                    paymentAccount = "Meghna Bank",
                    notes = "Clear remaining Meghna card debt over 4 equal months."
                ),
                FuturePlanEntity(
                    title = "Personal Debt 2 Clear-off",
                    planType = PlanType.DEBT_REPAYMENT,
                    totalTargetAmount = 25000.0,
                    monthlyInstallmentAmount = 5000.0,
                    startMonthKey = currentMonthKey,
                    durationMonths = 5,
                    paidAmount = 5000.0,
                    categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                    categoryName = "Debt 2",
                    paymentAccount = "Bank Transfer",
                    notes = "Monthly installment of 5,000৳ until clear."
                ),
                FuturePlanEntity(
                    title = "DPS Savings Target",
                    planType = PlanType.INVESTMENT_DPS,
                    totalTargetAmount = 12000.0,
                    monthlyInstallmentAmount = 1000.0,
                    startMonthKey = currentMonthKey,
                    durationMonths = 12,
                    paidAmount = 2000.0,
                    categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                    categoryName = "DPS",
                    paymentAccount = "MTB Bank",
                    notes = "Recurring DPS deposit 1,000৳/mo for 1 year."
                ),
                FuturePlanEntity(
                    title = "Khulna Family & Travel Fund",
                    planType = PlanType.FUTURE_EXPENSE,
                    totalTargetAmount = 15000.0,
                    monthlyInstallmentAmount = 5000.0,
                    startMonthKey = currentMonthKey,
                    durationMonths = 3,
                    paidAmount = 5000.0,
                    categoryGroup = CategoryGroup.LIFESTYLE,
                    categoryName = "Khulna",
                    paymentAccount = "bKash",
                    notes = "3 months allocation for family travel and expenses."
                )
            )
            planDao.insertAll(initialPlans)
        }
        if (accountabilityDao.getCount() == 0) {
            accountabilityDao.insertAll(
                listOf(
                    AccountabilityRuleEntity(
                        title = "Boundary with Colleagues",
                        content = "Colleagues are not friends.",
                        category = "Rule",
                        isPinned = true
                    ),
                    AccountabilityRuleEntity(
                        title = "Privacy on Personal Finance",
                        content = "Don't share personal finance or other info with them.",
                        category = "Principle",
                        isPinned = true
                    ),
                    AccountabilityRuleEntity(
                        title = "Workplace Loyalty Insight",
                        content = "They are more loyal to themselves/the company than you.",
                        category = "Principle",
                        isPinned = true
                    ),
                    AccountabilityRuleEntity(
                        title = "Meghna to bKash Charge Alert",
                        content = "Meghna theke 2 bkash A/C use kore bill pay korle 200 taka charge jabe.",
                        category = "Warning",
                        isPinned = true
                    )
                )
            )
        }
    }
}

suspend fun populateInitialData(database: AppDatabase) {
    val budgetDao = database.budgetSettingDao()
    val accountabilityDao = database.accountabilityDao()
    val transactionDao = database.transactionDao()

    // 1. Initial Budget Settings
    budgetDao.insertAll(
        listOf(
            BudgetSettingEntity(CategoryGroup.BILLS, 53f),
            BudgetSettingEntity(CategoryGroup.LIFESTYLE, 24f),
            BudgetSettingEntity(CategoryGroup.DEBT_AND_SAVINGS, 23f)
        )
    )

    // 2. Initial Personal Finance Accountability Rules
    accountabilityDao.insertAll(
        listOf(
            AccountabilityRuleEntity(
                title = "Boundary with Colleagues",
                content = "Colleagues are not friends.",
                category = "Rule",
                isPinned = true
            ),
            AccountabilityRuleEntity(
                title = "Privacy on Personal Finance",
                content = "Don't share personal finance or other info with them.",
                category = "Principle",
                isPinned = true
            ),
            AccountabilityRuleEntity(
                title = "Workplace Loyalty Insight",
                content = "They are more loyal to themselves/the company than you.",
                category = "Principle",
                isPinned = true
            ),
            AccountabilityRuleEntity(
                title = "Meghna to bKash Charge Alert",
                content = "Meghna theke 2 bkash A/C use kore bill pay korle 200 taka charge jabe.",
                category = "Warning",
                isPinned = true
            )
        )
    )

    // 3. Populate default sample / user's monthly ledger data
    val currentMonthKey = DateUtils.currentMonthKey()
    val now = System.currentTimeMillis()

    val initialTransactions = listOf(
        // Earnings
        TransactionEntity(
            title = "Base Salary",
            amount = 39520.0,
            expression = "39520",
            type = TransactionType.INCOME,
            categoryGroup = CategoryGroup.INCOME_BASE,
            categoryName = "Base Salary",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Bank Account",
            tags = "Salary,Base",
            notes = "Primary monthly basic salary"
        ),
        TransactionEntity(
            title = "Daily Working Rate",
            amount = 8400.0,
            expression = "400*21",
            type = TransactionType.INCOME,
            categoryGroup = CategoryGroup.INCOME_BASE,
            categoryName = "Daily Allowance",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Bank Account",
            tags = "DailyAllowance,21Days",
            notes = "400৳ per day for 21 days"
        ),
        TransactionEntity(
            title = "Extra Income",
            amount = 100.0,
            expression = "100",
            type = TransactionType.INCOME,
            categoryGroup = CategoryGroup.INCOME_EXTRA,
            categoryName = "Extra",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Bonus,Extra",
            notes = "Miscellaneous extra earnings"
        ),

        // 1. Bills (53% Target)
        TransactionEntity(
            title = "Home Support",
            amount = 11000.0,
            expression = "11000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.BILLS,
            categoryName = "Home",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Bank Transfer",
            tags = "Home,Family",
            isPaid = true
        ),
        TransactionEntity(
            title = "Rent",
            amount = 6760.0,
            expression = "3500+3260",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.BILLS,
            categoryName = "Rent",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Rent,Housing",
            notes = "Split breakdown: 3500 + 3260",
            isPaid = true
        ),
        TransactionEntity(
            title = "Health & Medical",
            amount = 5026.0,
            expression = "5026",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.BILLS,
            categoryName = "Health",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Cash",
            plannedAmount = 4500.0,
            tags = "Health,Medicine",
            notes = "Budget was 4500, actual 5026",
            isPaid = true
        ),
        TransactionEntity(
            title = "Electricity Bill",
            amount = 1000.0,
            expression = "1000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.BILLS,
            categoryName = "Electricity",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Utilities,Electricity",
            isPaid = true
        ),
        TransactionEntity(
            title = "Internet Bill",
            amount = 1175.0,
            expression = "500+675",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.BILLS,
            categoryName = "Internet",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Utilities,Internet",
            notes = "500 + 675",
            isPaid = true
        ),

        // 2. Life Style (24% Target)
        TransactionEntity(
            title = "Khulna Support",
            amount = 5000.0,
            expression = "5000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.LIFESTYLE,
            categoryName = "Khulna",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Family,Khulna",
            isPaid = true
        ),
        TransactionEntity(
            title = "Mim Support",
            amount = 4000.0,
            expression = "4000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.LIFESTYLE,
            categoryName = "Mim",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Family,Mim",
            isPaid = true
        ),
        TransactionEntity(
            title = "Pocket Money",
            amount = 0.0,
            expression = "0",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.LIFESTYLE,
            categoryName = "Pocket Money",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Cash",
            plannedAmount = 2000.0,
            tags = "Personal,Daily",
            isPaid = false
        ),

        // 3. Debt & Savings (23% Target)
        TransactionEntity(
            title = "Debt 1 Repayment",
            amount = 5000.0,
            expression = "3000+(1000+1000)",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "Debt 1",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "bKash",
            tags = "Debt,Repayment",
            notes = "3000 + (1000 + 1000)",
            isPaid = true
        ),
        TransactionEntity(
            title = "Debt 2 Repayment",
            amount = 5000.0,
            expression = "5000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "Debt 2",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Bank Transfer",
            tags = "Debt",
            isPaid = true
        ),
        TransactionEntity(
            title = "Credit Card Payment",
            amount = 1709.0,
            expression = "1709",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "Card",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "MTB Bank",
            tags = "Card,CreditCard",
            isPaid = true
        ),
        TransactionEntity(
            title = "DPS Savings 1",
            amount = 1000.0,
            expression = "1000",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "DPS",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "MTB Bank",
            tags = "Savings,DPS",
            notes = "Monthly deposit pension scheme",
            isPaid = true
        ),
        TransactionEntity(
            title = "DPS Savings 2",
            amount = 231.0,
            expression = "231",
            type = TransactionType.EXPENSE,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "DPS 2",
            monthYearKey = currentMonthKey,
            dateMillis = now,
            paymentAccount = "Meghna Bank",
            tags = "Savings,DPS",
            isPaid = true
        )
    )

    transactionDao.insertAll(initialTransactions)

    // 4. Initial Multi-Month Plans & Repayments
    val planDao = database.planDao()
    val initialPlans = listOf(
        FuturePlanEntity(
            title = "MTB Bank Loan Repayment",
            planType = PlanType.DEBT_REPAYMENT,
            totalTargetAmount = 30000.0,
            monthlyInstallmentAmount = 5000.0,
            startMonthKey = currentMonthKey,
            durationMonths = 6,
            paidAmount = 10000.0,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "Debt 1",
            paymentAccount = "MTB Bank",
            notes = "Pay 5,000৳ by 10th of every month. 2 installments already cleared."
        ),
        FuturePlanEntity(
            title = "Personal Debt 2 Clear-off",
            planType = PlanType.DEBT_REPAYMENT,
            totalTargetAmount = 25000.0,
            monthlyInstallmentAmount = 5000.0,
            startMonthKey = currentMonthKey,
            durationMonths = 5,
            paidAmount = 5000.0,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "Debt 2",
            paymentAccount = "Bank Transfer",
            notes = "Monthly installment of 5,000৳ until clear."
        ),
        FuturePlanEntity(
            title = "DPS Savings Target",
            planType = PlanType.INVESTMENT_DPS,
            totalTargetAmount = 12000.0,
            monthlyInstallmentAmount = 1000.0,
            startMonthKey = currentMonthKey,
            durationMonths = 12,
            paidAmount = 2000.0,
            categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
            categoryName = "DPS",
            paymentAccount = "MTB Bank",
            notes = "Recurring DPS deposit 1,000৳/mo for 1 year."
        ),
        FuturePlanEntity(
            title = "Khulna Family & Travel Fund",
            planType = PlanType.FUTURE_EXPENSE,
            totalTargetAmount = 15000.0,
            monthlyInstallmentAmount = 5000.0,
            startMonthKey = currentMonthKey,
            durationMonths = 3,
            paidAmount = 5000.0,
            categoryGroup = CategoryGroup.LIFESTYLE,
            categoryName = "Khulna",
            paymentAccount = "bKash",
            notes = "3 months allocation for family travel and expenses."
        )
    )
    planDao.insertAll(initialPlans)
}

