package com.example.data.repository

import com.example.data.local.AccountabilityDao
import com.example.data.local.BudgetSettingDao
import com.example.data.local.PlanDao
import com.example.data.local.TransactionDao
import com.example.data.model.AccountabilityRuleEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.FuturePlanEntity
import com.example.data.model.MonthlySummary
import com.example.data.model.PlanType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val budgetSettingDao: BudgetSettingDao,
    private val accountabilityDao: AccountabilityDao,
    private val planDao: PlanDao
) {
    fun getTransactionsForMonth(monthKey: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsForMonth(monthKey)

    fun getAllTransactions(): Flow<List<TransactionEntity>> =
        transactionDao.getAllTransactions()

    fun getUpcomingReminders(): Flow<List<TransactionEntity>> =
        transactionDao.getUpcomingReminders()

    fun getBudgetSettings(): Flow<List<BudgetSettingEntity>> =
        budgetSettingDao.getAllBudgetSettings()

    fun getAccountabilityRules(): Flow<List<AccountabilityRuleEntity>> =
        accountabilityDao.getAllRules()

    fun getAllPlans(): Flow<List<FuturePlanEntity>> =
        planDao.getAllPlans()

    suspend fun addOrUpdatePlan(plan: FuturePlanEntity): Long =
        planDao.insertPlan(plan)

    suspend fun deletePlan(plan: FuturePlanEntity) =
        planDao.deletePlan(plan)

    suspend fun deletePlan(id: Long) =
        planDao.deletePlanById(id)

    suspend fun recordPlanPayment(plan: FuturePlanEntity, currentMonthKey: String): TransactionEntity {
        // Increment paid amount
        val newPaid = (plan.paidAmount + plan.monthlyInstallmentAmount).coerceAtMost(plan.totalTargetAmount)
        val isDone = newPaid >= plan.totalTargetAmount
        planDao.updatePlan(plan.copy(paidAmount = newPaid, isCompleted = isDone))

        // Create transaction in current ledger
        val transaction = TransactionEntity(
            title = "${plan.title} (Plan Payment)",
            amount = plan.monthlyInstallmentAmount,
            expression = "${plan.monthlyInstallmentAmount.toInt()}",
            type = if (plan.planType == PlanType.SAVINGS_GOAL || plan.planType == PlanType.INVESTMENT_DPS || plan.planType == PlanType.DEBT_REPAYMENT) {
                TransactionType.EXPENSE
            } else {
                TransactionType.EXPENSE
            },
            categoryGroup = plan.categoryGroup,
            categoryName = plan.categoryName,
            monthYearKey = currentMonthKey,
            dateMillis = System.currentTimeMillis(),
            paymentAccount = plan.paymentAccount,
            tags = "PlanPayment,${plan.planType.name}",
            notes = "Auto-recorded installment for plan: ${plan.title} (${newPaid.toInt()}/${plan.totalTargetAmount.toInt()}৳)",
            isPaid = true
        )
        transactionDao.insertTransaction(transaction)
        return transaction
    }

    fun getMonthlySummary(monthKey: String): Flow<MonthlySummary> {
        return combine(
            transactionDao.getTransactionsForMonth(monthKey),
            budgetSettingDao.getAllBudgetSettings()
        ) { transactions, _ ->
            calculateSummary(monthKey, transactions)
        }
    }

    private fun calculateSummary(monthKey: String, transactions: List<TransactionEntity>): MonthlySummary {
        var baseIncome = 0.0
        var dailyRateIncome = 0.0
        var extraIncome = 0.0

        var billsTotal = 0.0
        var lifestyleTotal = 0.0
        var debtAndSavingsTotal = 0.0

        transactions.forEach { tx ->
            when (tx.type) {
                TransactionType.INCOME -> {
                    when (tx.categoryGroup) {
                        CategoryGroup.INCOME_EXTRA -> extraIncome += tx.amount
                        CategoryGroup.INCOME_BASE -> {
                            if (tx.expression.contains("*") || tx.tags.contains("Daily", ignoreCase = true)) {
                                dailyRateIncome += tx.amount
                            } else {
                                baseIncome += tx.amount
                            }
                        }
                        else -> {
                            if (tx.categoryName.contains("Extra", ignoreCase = true)) {
                                extraIncome += tx.amount
                            } else {
                                baseIncome += tx.amount
                            }
                        }
                    }
                }
                TransactionType.EXPENSE -> {
                    when (tx.categoryGroup) {
                        CategoryGroup.BILLS -> billsTotal += tx.amount
                        CategoryGroup.LIFESTYLE -> lifestyleTotal += tx.amount
                        CategoryGroup.DEBT_AND_SAVINGS -> debtAndSavingsTotal += tx.amount
                        else -> billsTotal += tx.amount
                    }
                }
            }
        }

        val totalIncome = baseIncome + dailyRateIncome + extraIncome
        val totalExpenses = billsTotal + lifestyleTotal + debtAndSavingsTotal
        val netBalance = totalIncome - totalExpenses

        val billsPercent = if (totalExpenses > 0) ((billsTotal / totalExpenses) * 100).toFloat() else 0f
        val lifestylePercent = if (totalExpenses > 0) ((lifestyleTotal / totalExpenses) * 100).toFloat() else 0f
        val debtSavingsPercent = if (totalExpenses > 0) ((debtAndSavingsTotal / totalExpenses) * 100).toFloat() else 0f

        return MonthlySummary(
            monthYearKey = monthKey,
            baseIncome = baseIncome,
            dailyRateIncome = dailyRateIncome,
            extraIncome = extraIncome,
            totalIncome = totalIncome,
            billsTotal = billsTotal,
            lifestyleTotal = lifestyleTotal,
            debtAndSavingsTotal = debtAndSavingsTotal,
            totalExpenses = totalExpenses,
            netBalance = netBalance,
            extraBuffer = if (netBalance > 0) netBalance else 0.0,
            billsPercentage = billsPercent,
            lifestylePercentage = lifestylePercent,
            debtSavingsPercentage = debtSavingsPercent
        )
    }

    suspend fun addOrUpdateTransaction(transaction: TransactionEntity): Long {
        return transactionDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(id: Long) {
        transactionDao.deleteById(id)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun saveBudgetSetting(setting: BudgetSettingEntity) {
        budgetSettingDao.insertOrUpdateSetting(setting)
    }

    suspend fun addRule(rule: AccountabilityRuleEntity): Long {
        return accountabilityDao.insertRule(rule)
    }

    suspend fun updateRule(rule: AccountabilityRuleEntity) {
        accountabilityDao.updateRule(rule)
    }

    suspend fun deleteRule(rule: AccountabilityRuleEntity) {
        accountabilityDao.deleteRule(rule)
    }

    suspend fun populateTemplateForMonth(monthKey: String) {
        val now = System.currentTimeMillis()
        val templateItems = listOf(
            // Earnings
            TransactionEntity(
                title = "Base Salary",
                amount = 39520.0,
                expression = "39520",
                type = TransactionType.INCOME,
                categoryGroup = CategoryGroup.INCOME_BASE,
                categoryName = "Base Salary",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Bank Account",
                tags = "Salary,Base",
                notes = "Primary monthly basic salary"
            ),
            TransactionEntity(
                title = "Daily Working Rate",
                amount = 8400.0,
                expression = "400*21",
                type = TransactionType.INCOME,
                categoryGroup = CategoryGroup.INCOME_BASE,
                categoryName = "Daily Allowance",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Bank Account",
                tags = "DailyAllowance,21Days",
                notes = "400৳ per day for 21 days"
            ),
            TransactionEntity(
                title = "Extra Income",
                amount = 100.0,
                expression = "100",
                type = TransactionType.INCOME,
                categoryGroup = CategoryGroup.INCOME_EXTRA,
                categoryName = "Extra",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Bonus,Extra",
                notes = "Miscellaneous extra earnings"
            ),

            // Bills
            TransactionEntity(
                title = "Home Support",
                amount = 11000.0,
                expression = "11000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.BILLS,
                categoryName = "Home",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Bank Transfer",
                tags = "Home,Family",
                isPaid = false
            ),
            TransactionEntity(
                title = "Rent",
                amount = 6760.0,
                expression = "3500+3260",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.BILLS,
                categoryName = "Rent",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Rent,Housing",
                notes = "Split breakdown: 3500 + 3260",
                isPaid = false
            ),
            TransactionEntity(
                title = "Health & Medical",
                amount = 4500.0,
                expression = "4500",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.BILLS,
                categoryName = "Health",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Cash",
                plannedAmount = 4500.0,
                tags = "Health,Medicine",
                notes = "Budget: 4500",
                isPaid = false
            ),
            TransactionEntity(
                title = "Electricity Bill",
                amount = 1000.0,
                expression = "1000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.BILLS,
                categoryName = "Electricity",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Utilities,Electricity",
                isPaid = false
            ),
            TransactionEntity(
                title = "Internet Bill",
                amount = 1175.0,
                expression = "500+675",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.BILLS,
                categoryName = "Internet",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Utilities,Internet",
                notes = "500 + 675",
                isPaid = false
            ),

            // Lifestyle
            TransactionEntity(
                title = "Khulna Support",
                amount = 5000.0,
                expression = "5000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.LIFESTYLE,
                categoryName = "Khulna",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Family,Khulna",
                isPaid = false
            ),
            TransactionEntity(
                title = "Mim Support",
                amount = 4000.0,
                expression = "4000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.LIFESTYLE,
                categoryName = "Mim",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Family,Mim",
                isPaid = false
            ),
            TransactionEntity(
                title = "Pocket Money",
                amount = 0.0,
                expression = "0",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.LIFESTYLE,
                categoryName = "Pocket Money",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Cash",
                plannedAmount = 2000.0,
                tags = "Personal,Daily",
                isPaid = false
            ),

            // Debt & Savings
            TransactionEntity(
                title = "Debt 1 Repayment",
                amount = 5000.0,
                expression = "3000+(1000+1000)",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                categoryName = "Debt 1",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "bKash",
                tags = "Debt,Repayment",
                notes = "3000 + (1000 + 1000)",
                isPaid = false
            ),
            TransactionEntity(
                title = "Debt 2 Repayment",
                amount = 5000.0,
                expression = "5000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                categoryName = "Debt 2",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Bank Transfer",
                tags = "Debt",
                isPaid = false
            ),
            TransactionEntity(
                title = "Credit Card Payment",
                amount = 1709.0,
                expression = "1709",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                categoryName = "Card",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "MTB Bank",
                tags = "Card,CreditCard",
                isPaid = false
            ),
            TransactionEntity(
                title = "DPS Savings 1",
                amount = 1000.0,
                expression = "1000",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                categoryName = "DPS",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "MTB Bank",
                tags = "Savings,DPS",
                notes = "Monthly deposit pension scheme",
                isPaid = false
            ),
            TransactionEntity(
                title = "DPS Savings 2",
                amount = 231.0,
                expression = "231",
                type = TransactionType.EXPENSE,
                categoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
                categoryName = "DPS 2",
                monthYearKey = monthKey,
                dateMillis = now,
                paymentAccount = "Meghna Bank",
                tags = "Savings,DPS",
                isPaid = false
            )
        )
        transactionDao.insertAll(templateItems)
    }

    suspend fun exportDataAsJson(allTransactions: List<TransactionEntity>, allRules: List<AccountabilityRuleEntity>): String {
        val root = JSONObject()
        val txArray = JSONArray()
        allTransactions.forEach { tx ->
            val obj = JSONObject().apply {
                put("title", tx.title)
                put("amount", tx.amount)
                put("expression", tx.expression)
                put("type", tx.type.name)
                put("categoryGroup", tx.categoryGroup.name)
                put("categoryName", tx.categoryName)
                put("subcategory", tx.subcategory)
                put("monthYearKey", tx.monthYearKey)
                put("dateMillis", tx.dateMillis)
                put("paymentAccount", tx.paymentAccount)
                put("tags", tx.tags)
                put("notes", tx.notes)
                put("isPaid", tx.isPaid)
                tx.plannedAmount?.let { put("plannedAmount", it) }
            }
            txArray.put(obj)
        }
        root.put("transactions", txArray)

        val rulesArray = JSONArray()
        allRules.forEach { rule ->
            val obj = JSONObject().apply {
                put("title", rule.title)
                put("content", rule.content)
                put("category", rule.category)
                put("isPinned", rule.isPinned)
            }
            rulesArray.put(obj)
        }
        root.put("accountabilityRules", rulesArray)
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        return root.toString(2)
    }

    suspend fun importDataFromJson(jsonStr: String): Boolean {
        return try {
            val root = JSONObject(jsonStr)
            if (root.has("transactions")) {
                val txArray = root.getJSONArray("transactions")
                val list = mutableListOf<TransactionEntity>()
                for (i in 0 until txArray.length()) {
                    val obj = txArray.getJSONObject(i)
                    list.add(
                        TransactionEntity(
                            title = obj.optString("title", "Imported Item"),
                            amount = obj.optDouble("amount", 0.0),
                            expression = obj.optString("expression", ""),
                            type = TransactionType.valueOf(obj.optString("type", "EXPENSE")),
                            categoryGroup = CategoryGroup.valueOf(obj.optString("categoryGroup", "BILLS")),
                            categoryName = obj.optString("categoryName", "General"),
                            subcategory = obj.optString("subcategory", ""),
                            monthYearKey = obj.optString("monthYearKey", DateUtils.currentMonthKey()),
                            dateMillis = obj.optLong("dateMillis", System.currentTimeMillis()),
                            paymentAccount = obj.optString("paymentAccount", "Cash"),
                            tags = obj.optString("tags", ""),
                            notes = obj.optString("notes", ""),
                            isPaid = obj.optBoolean("isPaid", true),
                            plannedAmount = if (obj.has("plannedAmount")) obj.getDouble("plannedAmount") else null
                        )
                    )
                }
                transactionDao.insertAll(list)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
